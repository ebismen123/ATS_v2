/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState, useRef } from "react";
import { onValue, ref, push, update, remove, serverTimestamp } from "firebase/database";
import { database, journalsRef } from "./firebase";
import { Journal, ProcessStatus, ActivityLog, PaymentStatus, BillingTiming } from "./types";
import { StatCards } from "./components/StatCards";
import { NotificationLog } from "./components/NotificationLog";
import { JournalRow } from "./components/JournalRow";
import { JournalFormModal } from "./components/JournalFormModal";
import { UrlInputModal } from "./components/UrlInputModal";
import { DocGeneratorModal } from "./components/DocGeneratorModal";
import { 
  Plus, 
  Search, 
  RotateCcw, 
  Bell, 
  BookOpen, 
  AlertCircle,
  Clock,
  LogOut,
  Info,
  CheckCircle2,
  XCircle,
  ChevronsUpDown
} from "lucide-react";

export default function App() {
  const [journals, setJournals] = useState<Journal[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Search & Filters
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState("");
  const [filterJournal, setFilterJournal] = useState("");
  const [filterStatus, setFilterStatus] = useState("");
  const [filterPayment, setFilterPayment] = useState("");
  const [isActionNeededFiltered, setIsActionNeededFiltered] = useState(false);

  // Sorting columns
  const [sortByDeadline, setSortByDeadline] = useState<"asc" | "desc">("asc");

  // Notifications permission state
  const [hasNotificationPermission, setHasNotificationPermission] = useState<"default" | "granted" | "denied">("default");

  // Logs & Toasts System
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [toasts, setToasts] = useState<{ id: string; title: string; text: string; type: "info" | "success" | "warning" }[]>([]);

  // Modals Controller
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingJournal, setEditingJournal] = useState<Journal | null>(null);
  const [formTitle, setFormTitle] = useState("Tambah Data Jurnal Baru");

  const [isUrlModalOpen, setIsUrlModalOpen] = useState(false);
  const [urlModalType, setUrlModalType] = useState<"publishedUrl" | "loaUrl" | "invoiceUrl" | null>(null);
  const [urlModalJournalId, setUrlModalJournalId] = useState("");

  // Document Generator Modal State
  const [isDocModalOpen, setIsDocModalOpen] = useState(false);
  const [docModalType, setDocModalType] = useState<"loa" | "invoice">("loa");
  const [docModalJournal, setDocModalJournal] = useState<Journal | null>(null);

  // Refs to trace status and data changes to generate automatic Real-time notifications
  const prevJournalsRef = useRef<Record<string, Journal>>({});
  const initialLoadRef = useRef(true);

  // Digital Clock live update
  const [currentTime, setCurrentTime] = useState("");

  useEffect(() => {
    const timer = setInterval(() => {
      const live = new Date().toLocaleTimeString("id-ID", {
        timeZone: "Asia/Jakarta",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      });
      setCurrentTime(live + " WIB");
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Sync Notification Logs from LocalStorage
  useEffect(() => {
    const savedLogs = localStorage.getItem("jeruk_manis_activity_logs");
    if (savedLogs) {
      try {
        setLogs(JSON.parse(savedLogs));
      } catch (e) {
        console.error("Failed to parse logs", e);
      }
    }

    if ("Notification" in window) {
      if (Notification.permission === "granted") {
        setHasNotificationPermission("granted");
      } else if (Notification.permission === "denied") {
        setHasNotificationPermission("denied");
      }
    }
  }, []);

  const saveLogsToStorage = (updatedLogs: ActivityLog[]) => {
    setLogs(updatedLogs);
    localStorage.setItem("jeruk_manis_activity_logs", JSON.stringify(updatedLogs));
  };

  const clearLogs = () => {
    saveLogsToStorage([]);
    triggerToast("Log Dihapus", "Seluruh riwayat notifikasi lokal berhasil disingkirkan.", "success");
  };

  // Push Toast Helper
  const triggerToast = (title: string, text: string, type: "info" | "success" | "warning" = "info") => {
    const id = Date.now().toString() + Math.random().toString();
    setToasts(prev => [...prev, { id, title, text, type }]);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 5000);
  };

  // Push Browser Notification Helper
  const triggerBrowserNotification = (title: string, body: string) => {
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification(title, {
        body,
        icon: "https://img.icons8.com/?size=100&id=XxRdzBNPGyUO&format=png&color=FF8C00",
      });
    }
  };

  // Handle live Database reads & generate automatic notifications on changes
  useEffect(() => {
    setIsLoading(true);
    
    const unsubscribe = onValue(journalsRef, (snapshot) => {
      setIsLoading(false);
      const data = snapshot.val() as Record<string, Journal> || {};
      
      const parsedJournals: Journal[] = Object.keys(data).map(key => ({
        id: key,
        ...data[key]
      }));

      setJournals(parsedJournals);

      // Analyze status diffs of previous journals for Real-time alerts
      if (!initialLoadRef.current) {
        const prevData = prevJournalsRef.current;
        
        // Find modified or created journals
        Object.keys(data).forEach((key) => {
          const prevItem = prevData[key];
          const newItem = data[key];

          if (!prevItem) {
            // Created!
            const logMsg = `Naskah baru ditambahkan untuk penulis ${newItem.authorName}`;
            const newLog: ActivityLog = {
              id: Date.now().toString() + Math.random().toString(),
              timestamp: Date.now(),
              message: logMsg,
              type: "create",
              authorName: newItem.authorName,
              journalTitle: newItem.title
            };
            
            // Append
            setLogs(current => {
              const u = [newLog, ...current].slice(0, 100);
              localStorage.setItem("jeruk_manis_activity_logs", JSON.stringify(u));
              return u;
            });

            triggerToast("Naskah Baru Didaftarkan", logMsg, "success");
            triggerBrowserNotification("🆕 Naskah Jurnal Baru", `${newItem.authorName}: "${newItem.title}"`);
          } else {
            // Checking if process status changed
            if (prevItem.process !== newItem.process) {
              const logMsg = `Alur proses diubah dari "${prevItem.process}" ke "${newItem.process}"`;
              const newLog: ActivityLog = {
                id: Date.now().toString() + Math.random().toString(),
                timestamp: Date.now(),
                message: logMsg,
                type: "status",
                authorName: newItem.authorName,
                journalTitle: newItem.title,
                previousValue: prevItem.process,
                newValue: newItem.process
              };

              setLogs(current => {
                const u = [newLog, ...current].slice(0, 100);
                localStorage.setItem("jeruk_manis_activity_logs", JSON.stringify(u));
                return u;
              });

              triggerToast(`Tahapan Berubah: ${newItem.authorName}`, `Status kini "${newItem.process}"`, "info");
              triggerBrowserNotification(`🚨 Progress: ${newItem.authorName}`, `Naskah "${newItem.title.substring(0, 30)}..." berubah ke "${newItem.process}"`);
            }

            // Checking if payment was changed
            if (prevItem.payment !== newItem.payment) {
              const logMsg = `Status pembayaran diset ke "${newItem.payment}" (sebelumnya: "${prevItem.payment}")`;
              const newLog: ActivityLog = {
                id: Date.now().toString() + Math.random().toString(),
                timestamp: Date.now(),
                message: logMsg,
                type: "payment",
                authorName: newItem.authorName,
                journalTitle: newItem.title,
                previousValue: prevItem.payment,
                newValue: newItem.payment
              };

              setLogs(current => {
                const u = [newLog, ...current].slice(0, 100);
                localStorage.setItem("jeruk_manis_activity_logs", JSON.stringify(u));
                return u;
              });

              triggerToast(`Status Pembayaran Bayar`, `${newItem.authorName} kini "${newItem.payment}"`, "success");
            }
          }
        });

        // Find deleted journals
        Object.keys(prevData).forEach((key) => {
          if (!data[key]) {
            const deletedItem = prevData[key];
            const logMsg = `Data naskah penulis ${deletedItem.authorName} dihapus dari sistem`;
            const newLog: ActivityLog = {
              id: Date.now().toString() + Math.random().toString(),
              timestamp: Date.now(),
              message: logMsg,
              type: "delete",
              authorName: deletedItem.authorName,
              journalTitle: deletedItem.title
            };

            setLogs(current => {
              const u = [newLog, ...current].slice(0, 100);
              localStorage.setItem("jeruk_manis_activity_logs", JSON.stringify(u));
              return u;
            });

            triggerToast("Data Jurnal Dihapus", logMsg, "warning");
          }
        });

      } else {
        // Stop initial flag
        initialLoadRef.current = false;
      }

      // Save to ref cache
      prevJournalsRef.current = data;
    }, (error) => {
      console.error("Firebase fetch error", error);
      setIsLoading(false);
      triggerToast("Koneksi Firebase Gagal", "Gagal memuat atau mendengarkan real-time database.", "warning");
    });

    return () => unsubscribe();
  }, []);

  // Checking upcoming deadlines periodically to trigger alarms
  useEffect(() => {
    const interval = setInterval(() => {
      if (journals.length === 0) return;
      
      const today = new Date();
      today.setHours(0,0,0,0);

      journals.forEach(j => {
        if (j.id && j.process !== "Publish") {
          const deadlineDate = new Date(j.deadline);
          const timeDiff = deadlineDate.getTime() - today.getTime();
          const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));

          // Check if today or 1-2 days left
          if (daysDiff >= 0 && daysDiff <= 2) {
            // Prevent spamming logs by checking session state alert storage
            const sessionKey = `warned_${j.id}_${daysDiff}`;
            if (!sessionStorage.getItem(sessionKey)) {
              sessionStorage.setItem(sessionKey, "true");
              const alertMsg = `Deadline tersisa ${daysDiff === 0 ? "hari ini!" : `${daysDiff} hari!`} segera tindak lanjut.`;
              triggerBrowserNotification(`🚨 Lampu Merah Deadline: ${j.journalTarget}`, `${j.authorName}: "${j.title.substring(0, 30)}..." ${alertMsg}`);
              triggerToast("Pemberitahuan Kadaluarsa", `${j.authorName}: ${alertMsg}`, "warning");
            }
          }
        }
      });
    }, 30000); // Check every 30 seconds

    return () => clearInterval(interval);
  }, [journals]);

  // Handle Notifications Permission Request
  const requestNotificationPermission = () => {
    if (!("Notification" in window)) {
      alert("Browser Anda tidak mendukung notifikasi desktop.");
      return;
    }

    if (Notification.permission === "granted") {
      triggerToast("Sudah Aktif", "Izin notifikasi desktop sudah diaktifkan.", "success");
      return;
    }

    Notification.requestPermission().then(permission => {
      if (permission === "granted") {
        setHasNotificationPermission("granted");
        new Notification("Jeruk Manis ATS", {
          body: "Notifikasi sistem berhasil diaktifkan secara real-time!",
          icon: "https://img.icons8.com/?size=100&id=XxRdzBNPGyUO&format=png&color=000000"
        });
      } else {
        setHasNotificationPermission("denied");
        alert("Anda menolak izin notifikasi desktop. Silakan nyalakan di preferensi setelan browser.");
      }
    });
  };

  // Create or Update Journal Database
  const handleSaveJournal = (compiledData: Journal) => {
    if (editingJournal && editingJournal.id) {
      // Edit
      const journalId = editingJournal.id;
      update(ref(database, 'journals/' + journalId), compiledData)
        .then(() => {
          setIsFormOpen(false);
          setEditingJournal(null);
          triggerToast("Pembaruan Sukses", `Data naskah ${compiledData.authorName} berhasil disimpan.`, "success");
        })
        .catch(err => {
          alert("Gagal memperbarui database: " + err.message);
        });
    } else {
      // Push New
      const dbData = {
        ...compiledData,
        createdAt: serverTimestamp(),
        publishedUrl: "",
        loaUrl: "",
        invoiceUrl: ""
      };
      
      push(journalsRef, dbData)
        .then(() => {
          setIsFormOpen(false);
          triggerToast("Pendaftaran Sukses", `Naskah baru oleh ${compiledData.authorName} berhasil didaftarkan.`, "success");
        })
        .catch(err => {
          alert("Gagal mendaftarkan naskah: " + err.message);
        });
    }
  };

  // Quick Change Status Bubble Stepper Callback
  const handleQuickStatusChange = (journalId: string, authorName: string, title: string, nextStatus: ProcessStatus) => {
    update(ref(database, 'journals/' + journalId), { process: nextStatus })
      .then(() => {
        triggerToast("Status Diperbarui", `Naskah ${authorName} dipindahkan ke tahapan "${nextStatus}".`, "info");
      })
      .catch(err => alert("Gagal memperbarui status: " + err.message));
  };

  // Open Document URL Modals
  const handleOpenUrlModal = (journalId: string, type: "publishedUrl" | "loaUrl" | "invoiceUrl") => {
    setUrlModalJournalId(journalId);
    setUrlModalType(type);
    setIsUrlModalOpen(true);
  };

  // Save Document URLs
  const handleSaveUrl = (url: string) => {
    if (!urlModalJournalId || !urlModalType) return;
    
    const updateObj: Record<string, string> = {};
    updateObj[urlModalType] = url;

    update(ref(database, 'journals/' + urlModalJournalId), updateObj)
      .then(() => {
        setIsUrlModalOpen(false);
        triggerToast("Tautan Disimpan", `Tautan URL berkas berhasil dipasangkan ke naskah.`, "success");
      })
      .catch(err => alert("Gagal menyimpan tautan berkas: " + err.message));
  };

  // Delete Action
  const handleDeleteJournal = (journalId: string, authorName: string) => {
    if (window.confirm(`Apakah Anda yakin ingin menghapus data naskah penulis "${authorName}"? Tindakan ini tidak dapat dibatalkan.`)) {
      remove(ref(database, 'journals/' + journalId))
        .then(() => {
          triggerToast("Naskah Dihapus", `Naskah milik ${authorName} berhasil dibatalkan dan dihapus.`, "warning");
        })
        .catch(err => alert("Gagal menghapus jurnal: " + err.message));
    }
  };

  // Reset all filters utility
  const resetFilters = () => {
    setSearchQuery("");
    setFilterType("");
    setFilterJournal("");
    setFilterStatus("");
    setFilterPayment("");
    setIsActionNeededFiltered(false);
    triggerToast("Penyaringan Direset", "Menampilkan seluruh naskah tanpa filter pembatas.", "info");
  };

  // Toggle Needs Action Filter (Action Needed Filter)
  const toggleActionNeededFilter = () => {
    setIsActionNeededFiltered(prev => {
      const next = !prev;
      if (next) {
        triggerToast("Saringan Aktif", "Sistem melakukan filtrasi khusus pada naskah mendesak (deadline dekat atau pembayaran macet).", "info");
      }
      return next;
    });
  };

  // WhatsApp & Email Actions templates matching original logic
  const sendRevisionWhatsApp = (j: Journal) => {
    if (!j.phone) {
      alert("No HP penulis tidak ditemukan!");
      return;
    }
    let msg = `EDITOR DECISION\n\nYth. ${j.authorName},\n\n`;
    msg += `Berdasarkan hasil review, naskah Anda yang berjudul "${j.title}" memerlukan revisi.\n\n`;
    msg += `Mohon segera merevisi naskah sesuai catatan reviewer dan mengirimkannya kembali dalam waktu maksimal 3 hari. `;
    msg += `Apabila Anda membutuhkan tambahan waktu, silakan konfirmasi melalui kontak WhatsApp tim redaksi di 0896 6774 7299.\n\n`;
    msg += `Terima kasih atas kerja samanya.\nTim Editor Jurnal ${j.journalTarget}`;
    
    window.open(`https://wa.me/${j.phone}?text=${encodeURIComponent(msg)}`, "_blank");
  };

  const sendRevisionEmail = (j: Journal) => {
    if (!j.email) {
      alert("Email koresponden tidak ditemukan!");
      return;
    }
    const expectedSender = j.journalTarget === "EBISMEN" ? "ebismenamni@gmail.com" : "lppm.amni@gmail.com";
    const fullJournalName = j.journalTarget === "EBISMEN" ? "EBISMEN: Jurnal Ekonomi, Bisnis, dan Manajemen" : `Jurnal ${j.journalTarget}`;
    
    alert(`PENTING EMAIL GMAIL:\n\nPastikan Anda mengirim email ini menggunakan akun Gmail:\n👉 ${expectedSender}\n\nAnda dapat menukarkan profil akun di tab browser surat baru nanti.`);

    const to = j.email;
    const subject = `EDITOR DECISION - REVISION REQUIRED`;
    let body = `Yth. ${j.authorName},\n\n`;
    body += `Kami telah menyelesaikan proses review terhadap naskah Anda yang dikirimkan ke ${fullJournalName} dengan judul:\n`;
    body += `"${j.title}".\n\n`;
    body += `Berdasarkan hasil evaluasi reviewer, dengan ini kami menyampaikan bahwa naskah Anda memerlukan revisi. `;
    body += `Mohon segera perbaiki naskah Anda sesuai catatan reviewer dan kirimkan kembali kepada kami dalam waktu maksimal 3 hari ke depan.\n\n`;
    body += `Apabila Anda membutuhkan tambahan waktu, silakan konfirmasi melalui balasan email ini atau kontak WhatsApp tim redaksi di 0896 6774 7299.\n\n`;
    body += `Terima kasih atas kerja samanya.\n\nHormat kami,\nTim Editor Jurnal ${j.journalTarget}`;

    window.open(`https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(to)}&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`, "_blank");
  };

  const sendLoaInvoiceWhatsApp = (j: Journal) => {
    if (!j.phone) {
      alert("No HP penulis tidak ditemukan!");
      return;
    }
    if (!j.loaUrl && !j.invoiceUrl) {
      alert("Harap tambahkan tautan URL LoA atau Invoice terlebih dahulu!");
      return;
    }

    let msg = `Yth. ${j.authorName},\n\nBerikut kami sampaikan LoA (Letter of Acceptance) dari artikel yang berjudul "${j.title}".\n`;
    
    if (j.loaUrl) {
      msg += `\nLoA:\n${j.loaUrl}\n`;
    }
    if (j.invoiceUrl) {
      msg += `\nUntuk informasi pembayaran, silakan akses berkas invoice pada tautan berikut:\n${j.invoiceUrl}\n`;
    }

    if (j.payment === "Belum Bayar" && j.billingTiming === "Sekarang") {
      const price = Number(j.apcAmount || 0).toLocaleString('id-ID');
      msg += `\nSelanjutnya, mohon dapat menyelesaikan administrasi pembayaran sebesar Rp ${price} melalui:\n`;
      msg += `- DANA: 089667747299\n`;
      msg += `- Bank Mandiri: 1360034498730 (a.n Dhanan)\n`;
    }

    msg += `\nTerima kasih.\nTim Editor Jurnal ${j.journalTarget}`;

    window.open(`https://wa.me/${j.phone}?text=${encodeURIComponent(msg)}`, "_blank");
  };

  const sendLoaInvoiceEmail = (j: Journal) => {
    if (!j.email) {
      alert("Email koresponden tidak ditemukan!");
      return;
    }
    if (!j.loaUrl && !j.invoiceUrl) {
      alert("Harap tambahkan tautan URL LoA atau Invoice terlebih dahulu!");
      return;
    }

    const expectedSender = j.journalTarget === "EBISMEN" ? "ebismenamni@gmail.com" : "lppm.amni@gmail.com";
    const fullJournalName = j.journalTarget === "EBISMEN" ? "EBISMEN: Jurnal Ekonomi, Bisnis, dan Manajemen" : `Jurnal ${j.journalTarget}`;
    
    alert(`PENTING EMAIL GMAIL:\n\nPastikan Anda mengirim email ini menggunakan akun Gmail:\n👉 ${expectedSender}\n\nAnda dapat menukarkan profil akun di tab browser surat baru nanti.`);

    const to = j.email;
    const subject = `EDITOR DECISION`;
    let body = `Yth. ${j.authorName},\n\n`;
    body += `Kami telah menyelesaikan proses penilaian terhadap naskah yang Anda kirimkan ke ${fullJournalName} dengan judul:\n`;
    body += `"${j.title}".\n\n`;
    body += `Berdasarkan hasil evaluasi reviewer dan keputusan dewan editor, dengan ini kami menyampaikan bahwa naskah Anda dinyatakan diterima (Accept Submission) untuk dipublikasikan.\n\n`;
    
    if (j.loaUrl) {
      body += `Surat Keterangan Penerimaan (Letter of Acceptance/LoA) dapat diakses melalui tautan berikut:\n${j.loaUrl}\n\n`;
    }
    if (j.invoiceUrl) {
      body += `Invoice dapat diakses melalui tautan berikut:\n${j.invoiceUrl}\n\n`;
    }

    if (j.payment === "Belum Bayar" && j.billingTiming === "Sekarang") {
      const price = Number(j.apcAmount || 0).toLocaleString('id-ID');
      body += `Mohon dapat menyelesaikan administrasi pembayaran sebesar Rp ${price} melalui:\n`;
      body += `- DANA: 089667747299\n`;
      body += `- Bank Mandiri: 1360034498730 (a.n Dhanan)\n\n`;
    }

    body += `Mohon konfirmasi pembayaran dengan mengirimkan bukti transfer kepada tim editor setelah transaksi dilakukan.\n\n`;
    body += `Hormat kami,\nEditor in Chief\n${fullJournalName}`;

    window.open(`https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(to)}&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`, "_blank");
  };

  const sendPublishWhatsApp = (j: Journal) => {
    if (!j.phone) {
      alert("No HP penulis tidak ditemukan!");
      return;
    }
    if (!j.publishedUrl) {
      alert("Harap tentukan tautan URL artikel terbit terlebih dahulu!");
      return;
    }

    let msg = `Yth. ${j.authorName},\n\nArtikel Anda yang berjudul "${j.title}" telah terbit.\n`;
    msg += `\nLink Artikel:\n${j.publishedUrl}\n`;

    if (j.payment === "Belum Bayar" && j.billingTiming === "Nanti") {
      const price = Number(j.apcAmount || 0).toLocaleString('id-ID');
      msg += `\nSelanjutnya, mohon dapat menyelesaikan administrasi pembayaran sebesar Rp ${price} melalui:\n`;
      msg += `- DANA: 089667747299\n`;
      msg += `- Bank Mandiri: 1360034498730 (a.n Dhanan)\n`;
    }

    msg += `\nTerima kasih.\nTim Editor Jurnal ${j.journalTarget}`;

    window.open(`https://wa.me/${j.phone}?text=${encodeURIComponent(msg)}`, "_blank");
  };

  const sendPublishEmail = (j: Journal) => {
    if (!j.email) {
      alert("Email koresponden tidak ditemukan!");
      return;
    }
    if (!j.publishedUrl) {
      alert("Harap tentukan tautan URL artikel terbit terlebih dahulu!");
      return;
    }

    const expectedSender = j.journalTarget === "EBISMEN" ? "ebismenamni@gmail.com" : "lppm.amni@gmail.com";
    const fullJournalName = j.journalTarget === "EBISMEN" ? "EBISMEN: Jurnal Ekonomi, Bisnis, dan Manajemen" : `Jurnal ${j.journalTarget}`;
    const volumeStr = j.volume ? `Volume ${j.volume}` : "";
    const issueStr = j.issueNumber ? `Nomor ${j.issueNumber}` : "";
    const volIssue = [volumeStr, issueStr].filter(Boolean).join(" ");
    
    alert(`PENTING EMAIL GMAIL:\n\nPastikan Anda mengirim email ini menggunakan akun Gmail:\n👉 ${expectedSender}\n\nAnda dapat menukarkan profil akun di tab browser surat baru nanti.`);

    const to = j.email;
    const subject = `EDITOR DECISION`;
    let body = `Yth. ${j.authorName},\n\n`;
    body += `Kami beritahukan bahwa artikel Anda yang berjudul:\n`;
    body += `"${j.title}"\n`;
    body += `telah resmi diterbitkan pada ${fullJournalName}. ${volIssue}\n\n`;
    body += `Artikel dapat diakses melalui tautan berikut:\n${j.publishedUrl}\n\n`;

    if (j.payment === "Belum Bayar" && j.billingTiming === "Nanti") {
      const price = Number(j.apcAmount || 0).toLocaleString('id-ID');
      body += `Selanjutnya, mohon dapat menyelesaikan administrasi pembayaran sebesar Rp ${price} melalui:\n`;
      body += `- DANA: 089667747299\n`;
      body += `- Bank Mandiri: 1360034498730 (a.n Dhanan)\n\n`;
      body += `Mohon konfirmasi pembayaran dengan mengirimkan bukti transfer kepada tim editor setelah transaksi dilakukan.\n\n`;
    }

    body += `Hormat kami,\nEditor in Chief\n${fullJournalName}`;

    window.open(`https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(to)}&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`, "_blank");
  };

  // Filter journals dynamically in memory
  const filteredJournals = journals.filter(j => {
    // Search filter: author name, title, or articleNumber
    const term = searchQuery.toLowerCase();
    const matchesSearch = 
      j.authorName.toLowerCase().includes(term) || 
      j.title.toLowerCase().includes(term) || 
      j.articleNumber.toLowerCase().includes(term);

    const matchesType = !filterType || j.publicationType === filterType;
    const matchesJournal = !filterJournal || j.journalTarget === filterJournal;
    const matchesStatus = !filterStatus || j.process === filterStatus;
    const matchesPayment = !filterPayment || j.payment === filterPayment;

    // "Needs Action" Filter Constraint (Highly Visual requested Feature)
    let matchesActionNeeded = true;
    if (isActionNeededFiltered) {
      const todayDate = new Date();
      todayDate.setHours(0,0,0,0);
      const limitDate = new Date(j.deadline);
      const diff = Math.ceil((limitDate.getTime() - todayDate.getTime()) / (1000 * 3600 * 24));
      
      const isUrgent = diff <= 2 && j.process !== "Publish";
      const isOverdueAndNotPublished = diff < 0 && j.process !== "Publish";
      const isUnpaidUrgentBilling = j.payment === "Belum Bayar" && j.billingTiming === "Sekarang";

      matchesActionNeeded = isUrgent || isOverdueAndNotPublished || isUnpaidUrgentBilling;
    }

    return matchesSearch && matchesType && matchesJournal && matchesStatus && matchesPayment && matchesActionNeeded;
  });

  // Sort journals by deadline
  const sortedJournals = [...filteredJournals].sort((a, b) => {
    const timeA = new Date(a.deadline).getTime();
    const timeB = new Date(b.deadline).getTime();
    
    // Always put Publish at bottom, otherwise sorting by date
    const aIsPublish = a.process === "Publish" ? 1 : 0;
    const bIsPublish = b.process === "Publish" ? 1 : 0;
    
    if (aIsPublish !== bIsPublish) {
      return aIsPublish - bIsPublish;
    }

    return sortByDeadline === "asc" ? timeA - timeB : timeB - timeA;
  });

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-gray-800 flex flex-col relative antialiased">
      
      {/* Toast Notification Container (Top Right Corner floating) */}
      <div className="fixed top-20 right-5 z-50 flex flex-col gap-2.5 max-w-sm w-full pointer-events-none">
        {toasts.map(t => (
          <div 
            key={t.id} 
            className={`p-4 rounded-xl shadow-lg border text-xs leading-normal pointer-events-auto animate-scale-up flex gap-3 items-start ${
              t.type === "success" 
                ? "bg-emerald-50 border-emerald-200 text-emerald-900" 
                : t.type === "warning" 
                  ? "bg-red-50 border-red-200 text-red-900" 
                  : "bg-blue-50 border-blue-200 text-blue-900"
            }`}
          >
            <div className="mt-0.5">
              {t.type === "success" && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
              {t.type === "warning" && <AlertCircle className="w-4 h-4 text-red-600" />}
              {t.type === "info" && <Info className="w-4 h-4 text-blue-600" />}
            </div>
            <div className="flex-1">
              <p className="font-bold">{t.title}</p>
              <p className="text-gray-600 mt-1">{t.text}</p>
            </div>
            <button 
              type="button"
              onClick={() => setToasts(prev => prev.filter(x => x.id !== t.id))}
              className="font-bold text-gray-400 hover:text-gray-700 select-none pb-1"
            >
              ×
            </button>
          </div>
        ))}
      </div>

      {/* Main Header */}
      <header className="bg-white border-b border-slate-200 text-slate-800 sticky top-0 z-40 px-6 py-4 shadow-xs">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          
          {/* Brand Logo & Name */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-md border border-indigo-500/50">
              <img 
                src="https://img.icons8.com/?size=100&id=XxRdzBNPGyUO&format=png&color=FFFFFF" 
                alt="Logo Jeruk" 
                className="h-7 w-7 object-contain"
              />
            </div>
            <div>
              <h1 className="text-xl font-black tracking-tight flex items-center gap-1.5 font-display text-indigo-950">
                Jeruk Manis <span className="text-[11px] font-bold bg-indigo-50 text-indigo-700 px-2.5 py-0.5 rounded-full uppercase ml-1">ATS</span>
              </h1>
              <p className="text-xs text-slate-500 font-medium">Article Journal tracking & administration center</p>
            </div>
          </div>

          {/* Time & Permission widgets */}
          <div className="flex items-center gap-5">
            {/* Live Clock displaying real-time admin tracking */}
            <div className="hidden md:flex items-center gap-2 bg-indigo-50 px-3.5 py-1.5 rounded-xl border border-indigo-100 text-xs font-mono text-indigo-700 font-bold">
              <Clock className="w-3.5 h-3.5 text-indigo-550" />
              <span>{currentTime || "Menghubungkan..."}</span>
            </div>

            {/* Notification Subscription Bell Button */}
            <button
              type="button"
              onClick={requestNotificationPermission}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold select-none transition-all ${
                hasNotificationPermission === "granted" 
                  ? "bg-emerald-50 text-emerald-700 border border-emerald-200" 
                  : hasNotificationPermission === "denied"
                    ? "bg-rose-50 text-rose-700 border border-rose-200 cursor-help"
                    : "bg-indigo-600 hover:bg-indigo-700 text-white border border-indigo-500 shadow-xs cursor-pointer"
              }`}
              title={
                hasNotificationPermission === "granted" 
                  ? "Notifikasi sistem berkala diaktifkan secara real-time" 
                  : "Nyalakan notifikasi desktop"
              }
            >
              <Bell className={`w-3.5 h-3.5 ${hasNotificationPermission === "granted" ? "animate-pulse" : ""}`} />
              <span>
                {hasNotificationPermission === "granted" 
                  ? "Alerts Active" 
                  : hasNotificationPermission === "denied" 
                    ? "Alerts Blocked" 
                    : "Aktifkan Bel Alert"}
              </span>
            </button>
          </div>

        </div>
      </header>

      {/* Main Container Workspace Grid */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-6 py-8">
        
        {/* Statistics Widgets Row */}
        <StatCards 
          journals={journals} 
          onSelectActionNeededFilter={toggleActionNeededFilter}
          isActionNeededFiltered={isActionNeededFiltered}
        />

        {/* Filters and Management Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
          
          {/* LEFT: Master Journal Tracking List */}
          <div className="lg:col-span-2 space-y-6">
            
            <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
                <div>
                  <h2 className="text-lg font-bold text-slate-800 flex items-center gap-1.5 font-display">
                    <BookOpen className="w-5 h-5 text-indigo-600" />
                    Manajemen Jurnal Penerbit
                  </h2>
                  <p className="text-xs text-gray-400 mt-0.5">Pantau, koordinasikan, dan kelola administrasi naskah editorial secara terintegrasi.</p>
                </div>

                {/* Create/Register Journal article button */}
                <button
                  type="button"
                  onClick={() => {
                    setEditingJournal(null);
                    setFormTitle("Daftarkan Naskah Baru");
                    setIsFormOpen(true);
                  }}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs hover:scale-101 active:scale-98 transition-all flex items-center justify-center gap-1.5 select-none cursor-pointer"
                >
                  <Plus className="w-4 h-4" /> Tambah Data Jurnal
                </button>
              </div>

              {/* Dynamic Search & Input Selector Panel */}
              <div className="space-y-4">
                
                {/* Text search input bar */}
                <div className="relative">
                  <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Cari artikel berdasarkan nama penulis, judul naskah, atau nomor artikel..."
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-250 text-xs focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-550 bg-slate-50/50"
                  />
                </div>

                {/* Option filters grid */}
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                  
                  {/* Filter 1: Pub Type */}
                  <select
                    value={filterType}
                    onChange={(e) => setFilterType(e.target.value)}
                    className="py-2.5 px-3.5 text-xs rounded-xl border border-slate-250 bg-white focus:outline-none focus:border-indigo-500 font-medium text-slate-705"
                  >
                    <option value="">Semua Jenis</option>
                    <option value="Reguler">Reguler</option>
                    <option value="Fast Track">Fast Track</option>
                  </select>

                  {/* Filter 2: Target Jurnal */}
                  <select
                    value={filterJournal}
                    onChange={(e) => setFilterJournal(e.target.value)}
                    className="py-2.5 px-3.5 text-xs rounded-xl border border-slate-250 bg-white focus:outline-none focus:border-indigo-500 font-medium text-slate-705"
                  >
                    <option value="">Semua Jurnal</option>
                    <option value="EBISMEN">EBISMEN</option>
                    <option value="WAWASAN">WAWASAN</option>
                    <option value="PROFIT">PROFIT</option>
                    <option value="POPULER">POPULER</option>
                    <option value="SIDU">SIDU</option>
                    <option value="INSDU">INSDU</option>
                    <option value="OCEAN">OCEAN</option>
                    <option value="KTI">KTI</option>
                    <option value="SEJAHTERA">SEJAHTERA</option>
                    <option value="KARUNIA">KARUNIA</option>
                    <option value="UNITECH">UNITECH</option>
                  </select>

                  {/* Filter 3: Process Status */}
                  <select
                    value={filterStatus}
                    onChange={(e) => setFilterStatus(e.target.value)}
                    className="py-2.5 px-3.5 text-xs rounded-xl border border-slate-250 bg-white focus:outline-none focus:border-indigo-500 font-medium text-slate-705"
                  >
                    <option value="">Semua Status</option>
                    <option value="Belum submit font-medium text-slate-705">Belum submit</option>
                    <option value="Sudah disubmit">Sudah disubmit</option>
                    <option value="Review">Review</option>
                    <option value="Editing">Editing</option>
                    <option value="LoA sudah terbit">LoA sudah terbit</option>
                    <option value="Publish">Publish</option>
                  </select>

                  {/* Filter 4: Payment Status */}
                  <select
                    value={filterPayment}
                    onChange={(e) => setFilterPayment(e.target.value)}
                    className="py-2.5 px-3.5 text-xs rounded-xl border border-slate-250 bg-white focus:outline-none focus:border-indigo-500 font-medium text-slate-705"
                  >
                    <option value="">Semua Pembayaran</option>
                    <option value="Sudah Bayar">Sudah Bayar</option>
                    <option value="Belum Bayar">Belum Bayar</option>
                  </select>

                  {/* Filter Reset Button */}
                  <button
                    type="button"
                    onClick={resetFilters}
                    className="bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold py-2.5 px-3.5 rounded-xl text-xs transition-colors flex items-center justify-center gap-1.5 col-span-2 sm:col-span-1 border border-slate-220 select-none cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Reset
                  </button>

                </div>

              </div>

              {/* Responsive Data Table */}
              <div className="overflow-x-auto border border-slate-150 rounded-2xl mt-6 bg-white shadow-xs">
                <table className="min-w-full divide-y divide-slate-150 text-left">
                  <thead className="bg-slate-50/75 border-b border-slate-100">
                    <tr>
                      <th className="px-5 py-3.5 text-xs font-bold text-slate-400 uppercase tracking-wider">Penulis & Afiliasi</th>
                      <th className="px-5 py-3.5 text-xs font-bold text-slate-400 uppercase tracking-wider">Judul & No. Artikel</th>
                      <th className="px-5 py-3.5 text-xs font-bold text-slate-400 uppercase tracking-wider">Target Jurnal</th>
                      
                      {/* Sortable Deadline Column Header */}
                      <th className="px-5 py-3.5 text-xs font-bold text-slate-400 uppercase tracking-wider">
                        <button
                          type="button"
                          onClick={() => setSortByDeadline(prev => prev === "asc" ? "desc" : "asc")}
                          className="flex items-center gap-1 hover:text-indigo-600 cursor-pointer"
                          title="Klik untuk mengurutkan deadline naskah"
                        >
                          Deadline Jurnal
                          <ChevronsUpDown className="w-3.5 h-3.5" />
                        </button>
                      </th>

                      <th className="px-5 py-3.5 text-xs font-bold text-orange-950 uppercase">Status Perjalanan</th>
                      <th className="px-5 py-3.5 text-xs font-bold text-orange-950 uppercase text-right">Proses Tahapan</th>
                      <th className="px-5 py-3.5 text-xs font-bold text-orange-950 uppercase text-right">Aksi</th>
                    </tr>
                  </thead>

                  <tbody className="divide-y divide-gray-100 bg-white">
                    {isLoading ? (
                      <tr>
                        <td colSpan={7} className="text-center py-20">
                          <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-orange-500 border-t-transparent mb-2" />
                          <p className="text-sm font-medium text-gray-400">Menghubungkan & Membaca Real-time Database...</p>
                        </td>
                      </tr>
                    ) : sortedJournals.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="text-center py-16">
                          <XCircle className="w-10 h-10 text-gray-300 mx-auto mb-3" />
                          <p className="text-sm font-bold text-gray-700">Tidak ada naskah ditemukan</p>
                          <p className="text-xs text-gray-450 mt-1">Coba sesuaikan kata kunci pencarian atau ubah filter di atas.</p>
                          {(searchQuery || filterType || filterJournal || filterStatus || filterPayment || isActionNeededFiltered) && (
                            <button
                              type="button"
                              onClick={resetFilters}
                              className="mt-4 px-3 py-1.5 inline-flex items-center gap-1 text-xs border border-gray-200 text-orange-600 rounded bg-orange-50/20 font-bold hover:bg-orange-50 transition-colors"
                            >
                              <RotateCcw className="w-3.5 h-3.5" /> Bersihkan Filter
                            </button>
                          )}
                        </td>
                      </tr>
                    ) : (
                      sortedJournals.map((journal) => (
                        <JournalRow
                          key={journal.id}
                          journal={journal}
                          onEdit={() => {
                            setEditingJournal(journal);
                            setFormTitle("Edit Data Jurnal");
                            setIsFormOpen(true);
                          }}
                          onDelete={() => handleDeleteJournal(journal.id!, journal.authorName)}
                          onQuickStatusChange={(nextStatus) => handleQuickStatusChange(journal.id!, journal.authorName, journal.title, nextStatus)}
                          onOpenUrlModal={(type) => handleOpenUrlModal(journal.id!, type)}
                          onGenerateDoc={(type) => {
                            setDocModalJournal(journal);
                            setDocModalType(type);
                            setIsDocModalOpen(true);
                          }}
                          
                          // Template messages triggers
                          onSendRevisionWhatsApp={() => sendRevisionWhatsApp(journal)}
                          onSendRevisionEmail={() => sendRevisionEmail(journal)}
                          onSendLoaInvoiceWhatsApp={() => sendLoaInvoiceWhatsApp(journal)}
                          onSendLoaInvoiceEmail={() => sendLoaInvoiceEmail(journal)}
                          onSendPublishWhatsApp={() => sendPublishWhatsApp(journal)}
                          onSendPublishEmail={() => sendPublishEmail(journal)}
                        />
                      ))
                    )}
                  </tbody>
                </table>
              </div>

            </div>

          </div>

          {/* RIGHT: Live Admin Notification center / Command center logs */}
          <div className="space-y-6">
            
            {/* Live activity logs feed */}
            <NotificationLog logs={logs} onClearLogs={clearLogs} />

            {/* Quick reference guide card */}
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs">
              <h4 className="font-bold text-xs text-indigo-600 uppercase tracking-widest border-b border-slate-100 pb-2 mb-4 flex items-center gap-1.5">
                <Info className="w-4 h-4 text-indigo-555" />
                Panduan Redaksi Jurnal
              </h4>
              <ul className="space-y-4 text-[11px] leading-relaxed text-slate-600">
                <li className="flex gap-2">
                  <span className="font-bold text-indigo-600 text-xs">01.</span>
                  <span><strong>Indikator Tahapan:</strong> Setiap baris memiliki 6 bola kemajuan interaktif untuk beralih status secara instan tanpa masuk form edit.</span>
                </li>
                <li className="flex gap-2">
                  <span className="font-bold text-indigo-600 text-xs">02.</span>
                  <span><strong>Butuh Tindak Lanjut:</strong> Penulis yang berdetak merah 🚨 adalah naskah mendekati deadline (≤ 2 hari) atau melewati batas waktu tanpa rilis naskah terbit.</span>
                </li>
                <li className="flex gap-2">
                  <span className="font-bold text-indigo-600 text-xs">03.</span>
                  <span><strong>Alokasi Rekening Tim:</strong> Rekening Mandiri (a.n Dhanan) & DANA tim redaksi tercetak langsung otomatis pada pesan penagihan yang draf instannya bisa dikirim per tombol WhatsApp / Email.</span>
                </li>
              </ul>
            </div>

          </div>

        </div>

        {/* Bottom Utility Bar (Pusat Kendali Pengelola & Target Terbit Bento Block) */}
        {(() => {
          const totalCount = journals.length;
          const publishedCount = journals.filter(j => j.process === "Publish").length;
          const rate = totalCount > 0 ? Math.round((publishedCount / totalCount) * 100) : 0;
          return (
            <section className="bg-gradient-to-r from-indigo-950 via-indigo-900 to-slate-900 rounded-3xl p-6 flex flex-col md:flex-row items-center justify-between text-white gap-6 shadow-xs mt-8">
              <div className="text-center md:text-left">
                <p className="text-indigo-200 text-xs font-bold uppercase tracking-widest">Publishing Target Q3</p>
                <p className="text-3xl font-black mt-1">
                  {rate}% 
                  <span className="text-xs font-medium text-indigo-300 ml-3">
                    ({publishedCount} dari {totalCount} naskah berhasil terbit)
                  </span>
                </p>
              </div>
              <div className="flex gap-2.5">
                <div className="h-12 w-2 bg-indigo-700/60 rounded-full"></div>
                <div className="h-16 w-2 bg-indigo-700/60 rounded-full"></div>
                <div className="h-10 w-2 bg-indigo-700/60 rounded-full"></div>
                <div className="h-20 w-2 bg-indigo-500 rounded-full shadow-[0_0_12px_rgba(99,102,241,0.5)]"></div>
                <div className="h-24 w-2 bg-indigo-400 rounded-full"></div>
                <div className="h-14 w-2 bg-indigo-700/60 rounded-full"></div>
              </div>
              <button 
                type="button"
                onClick={() => {
                  const headers = "No,Penulis,Afiliasi,Judul Jurnal,Target Jurnal,Status,Pembayaran\n";
                  const rows = journals.map((j, i) => 
                    `"${i+1}","${j.authorName}","${j.affiliation}","${j.title.replace(/"/g, '""')}","${j.journalTarget}","${j.process}","${j.payment}"`
                  ).join("\n");
                  
                  const blob = new Blob([headers + rows], { type: "text/csv;charset=utf-8;" });
                  const url = URL.createObjectURL(blob);
                  const link = document.createElement("a");
                  link.setAttribute("href", url);
                  link.setAttribute("download", `Laporan_Sistem_Jurnal_${new Date().toISOString().split('T')[0]}.csv`);
                  document.body.appendChild(link);
                  link.click();
                  document.body.removeChild(link);
                  triggerToast("Laporan Diunduh", "Berkas laporan berkala CSV sukses diekspor.", "success");
                }}
                className="bg-white text-indigo-950 hover:bg-indigo-50 active:scale-95 px-6 py-3 rounded-xl font-bold text-sm transition-all shadow-xs cursor-pointer"
              >
                Download Report CSV
              </button>
            </section>
          );
        })()}

      </main>

      {/* FOOTER */}
      <footer className="bg-slate-900 text-slate-400 border-t border-slate-800 py-8 mt-12">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs font-medium">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center">
              <img 
                src="https://img.icons8.com/?size=100&id=XxRdzBNPGyUO&format=png&color=FFFFFF" 
                alt="Orange white" 
                className="h-5 w-5 opacity-90"
              />
            </div>
            <div>
              <p className="text-sm font-bold text-slate-200">Jeruk Manis ATS</p>
              <p className="text-[10px] text-slate-500 mt-0.5">Aplikasi Khusus Buat Pengelola & Editor Jurnal</p>
            </div>
          </div>
          
          <div className="flex gap-4">
            <a href="https://wa.me/6289667747299" target="_blank" rel="noreferrer" className="hover:text-slate-200">Support</a>
            <span>•</span>
            <span className="text-slate-550">Jeruk Manis &copy; 2026. All rights preserved.</span>
          </div>
        </div>
      </footer>

      {/* Modals Controllers */}
      
      {/* 1. Add/Edit Journal Form Modal */}
      <JournalFormModal
        isOpen={isFormOpen}
        onClose={() => {
          setIsFormOpen(false);
          setEditingJournal(null);
        }}
        onSave={handleSaveJournal}
        initialData={editingJournal}
        title={formTitle}
      />

      {/* 2. Upload/Save Document URL Link Modal */}
      <UrlInputModal
        isOpen={isUrlModalOpen}
        onClose={() => {
          setIsUrlModalOpen(false);
          setUrlModalType(null);
          setUrlModalJournalId("");
        }}
        onSave={handleSaveUrl}
        type={urlModalType}
        initialUrl={
          editingJournal && urlModalType 
            ? (editingJournal[urlModalType] || "") 
            : journals.find(j => j.id === urlModalJournalId)?.[urlModalType!] || ""
        }
      />

      {/* 3. Document PDF Generator & Print Modal */}
      <DocGeneratorModal
        isOpen={isDocModalOpen}
        onClose={() => {
          setIsDocModalOpen(false);
          setDocModalJournal(null);
        }}
        journal={docModalJournal}
        defaultType={docModalType}
      />

    </div>
  );
}
