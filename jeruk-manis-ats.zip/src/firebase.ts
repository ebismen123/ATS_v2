import { initializeApp, getApps, getApp } from "firebase/app";
import { getDatabase, ref } from "firebase/database";

// Firebase configuration from legacy code
const firebaseConfig = {
    apiKey: "AIzaSyAA5ylO4TMtGnnPhrm1vGUDF6AafNSrOUQ",
    authDomain: "orange-journal-tracker.firebaseapp.com",
    databaseURL: "https://orange-journal-tracker-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "orange-journal-tracker",
    storageBucket: "orange-journal-tracker.appspot.com",
    messagingSenderId: "430973783779",
    appId: "1:430973783779:web:bc1ccf3b75ce8144fcffd6"
};

// Initialize Firebase app safely
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
const database = getDatabase(app);
const journalsRef = ref(database, 'journals');

export { app, database, journalsRef };
export default database;
