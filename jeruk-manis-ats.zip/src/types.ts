/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ProcessStatus = 
  | "Belum submit" 
  | "Sudah disubmit" 
  | "Review" 
  | "Editing" 
  | "LoA sudah terbit" 
  | "Publish";

export type PaymentStatus = "Sudah Bayar" | "Belum Bayar";

export type BillingTiming = "Sekarang" | "Nanti";

export type PublicationType = "Reguler" | "Fast Track";

export interface Journal {
  id?: string;
  entryDate: string;
  authorName: string;
  email: string;
  affiliation: string;
  title: string;
  articleNumber: string;
  volume: string | number;
  issueNumber: string | number;
  publishMonth: string;
  publishYear: string | number;
  phone: string;
  publicationType: PublicationType;
  apcAmount: number;
  journalTarget: string;
  deadline: string;
  process: ProcessStatus;
  payment: PaymentStatus;
  billingTiming: BillingTiming;
  createdAt?: any;
  publishedUrl?: string;
  loaUrl?: string;
  invoiceUrl?: string;
}

export interface ActivityLog {
  id: string;
  timestamp: number;
  message: string;
  type: "status" | "payment" | "billing" | "create" | "update" | "delete";
  authorName: string;
  journalTitle: string;
  previousValue?: string;
  newValue?: string;
}
