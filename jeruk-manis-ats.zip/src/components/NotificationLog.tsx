/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ActivityLog } from "../types";
import { Bell, Trash2, ShieldAlert, Award, FileSpreadsheet, RefreshCw } from "lucide-react";

interface NotificationLogProps {
  logs: ActivityLog[];
  onClearLogs: () => void;
}

export function NotificationLog({ logs, onClearLogs }: NotificationLogProps) {
  return (
    <div className="bg-white rounded-3xl border border-slate-200 p-6 flex flex-col shadow-xs">
      <div className="flex justify-between items-center mb-5">
        <h3 className="text-[15px] font-bold text-slate-800 flex items-center gap-2">
          <Bell className="w-4.5 h-4.5 text-indigo-505 animate-swing" />
          Log & Notifikasi Real-time
        </h3>
        {logs.length > 0 && (
          <button
            type="button"
            onClick={onClearLogs}
            className="text-[10px] font-bold text-slate-400 hover:text-rose-600 flex items-center gap-1 transition-colors px-2.5 py-1 rounded-lg border border-slate-200 bg-white"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Clear
          </button>
        )}
      </div>

      <div className="space-y-4 max-h-64 overflow-y-auto pr-1">
        {logs.length === 0 ? (
          <div className="text-center py-10 text-slate-400 border border-dashed border-slate-200 rounded-2xl p-4">
            <Bell className="w-8 h-8 text-slate-300 mx-auto mb-2 opacity-50" />
            <p className="text-xs font-semibold text-slate-600">Aliran Notifikasi Kosong</p>
            <p className="text-[10px] text-slate-400 mt-1">Setiap kali Anda mengubah alur berkas, rincian aktivitas tercatat otomatis secara live.</p>
          </div>
        ) : (
          logs.map((log) => {
            const timeStr = new Date(log.timestamp).toLocaleTimeString("id-ID", {
              hour: "2-digit",
              minute: "2-digit",
            });

            // Color-coded activity markers inspired by the system feed list
            let dotColor = "bg-slate-300";
            if (log.type === "create") {
              dotColor = "bg-emerald-505";
            } else if (log.type === "delete") {
              dotColor = "bg-rose-505";
            } else if (log.type === "status") {
              dotColor = "bg-indigo-505";
            } else if (log.type === "payment") {
              dotColor = "bg-amber-505";
            }

            return (
              <div
                key={log.id}
                className="flex gap-3 leading-normal border-b border-slate-50 pb-3 last:border-0 last:pb-0"
              >
                <div className={`w-2 h-2 rounded-full ${dotColor} mt-1.5 flex-shrink-0`} />
                <div className="flex-1">
                  <p className="text-xs text-slate-700 font-medium">
                    <span className="font-bold text-slate-900">{log.authorName}</span>: {log.message}
                  </p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[9px] font-semibold text-slate-400 font-mono">
                      {timeStr}
                    </span>
                    <span className="text-slate-300 text-[9px]">•</span>
                    <span className="text-[9px] text-slate-400 italic truncate max-w-[150px]" title={log.journalTitle}>
                      "{log.journalTitle}"
                    </span>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
