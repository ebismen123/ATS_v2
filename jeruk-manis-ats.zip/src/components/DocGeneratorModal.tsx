/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Journal } from "../types";
import { 
  X, 
  Printer, 
  FileText, 
  DollarSign, 
  Award, 
  Calendar, 
  User, 
  Building, 
  Type, 
  Hash, 
  RotateCcw,
  Check,
  Copy
} from "lucide-react";

interface DocGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
  journal: Journal | null;
  defaultType: "loa" | "invoice";
}

// Resilient roman numeral helper
function getRomanMonth(monthStr: string | undefined): string {
  if (!monthStr) return "V";
  const norm = monthStr.trim().toLowerCase();
  
  const monthNum = parseInt(norm, 10);
  if (!isNaN(monthNum)) {
    const romanMap = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"];
    if (monthNum >= 1 && monthNum <= 12) {
      return romanMap[monthNum - 1];
    }
  }

  if (norm.startsWith("jan")) return "I";
  if (norm.startsWith("feb")) return "II";
  if (norm.startsWith("mar")) return "III";
  if (norm.startsWith("apr")) return "IV";
  if (norm.startsWith("mei") || norm.startsWith("may")) return "V";
  if (norm.startsWith("jun")) return "VI";
  if (norm.startsWith("jul")) return "VII";
  if (norm.startsWith("agu") || norm.startsWith("aug")) return "VIII";
  if (norm.startsWith("sep")) return "IX";
  if (norm.startsWith("okt") || norm.startsWith("oct")) return "X";
  if (norm.startsWith("nov")) return "XI";
  if (norm.startsWith("des") || norm.startsWith("dec")) return "XII";

  return "V";
}

export function DocGeneratorModal({ isOpen, onClose, journal, defaultType }: DocGeneratorModalProps) {
  const [docType, setDocType] = useState<"loa" | "invoice">(defaultType);
  
  // Document State Variables for customizable tuning
  const [articleNumber, setArticleNumber] = useState("");
  const [authorName, setAuthorName] = useState("");
  const [affiliation, setAffiliation] = useState("");
  const [title, setTitle] = useState("");
  const [volume, setVolume] = useState("");
  const [issueNumber, setIssueNumber] = useState("");
  const [publishYear, setPublishYear] = useState("");
  const [romanMonth, setRomanMonth] = useState("V");
  const [letterNumber, setLetterNumber] = useState("");
  const [letterDate, setLetterDate] = useState("");
  const [apcAmount, setApcAmount] = useState(0);
  const [publicationType, setPublicationType] = useState("");
  const [paymentStatus, setPaymentStatus] = useState("");
  const [signatoryName, setSignatoryName] = useState("Iwan Mahendro, S.Kom., M.Pd., M.Kom.");
  const [copied, setCopied] = useState(false);

  // Sync state variables whenever journal or docType changes
  useEffect(() => {
    if (journal) {
      setArticleNumber(journal.articleNumber || "");
      setAuthorName(journal.authorName || "");
      setAffiliation(journal.affiliation || "");
      setTitle(journal.title || "");
      setVolume(String(journal.volume || "5"));
      setIssueNumber(String(journal.issueNumber || "2"));
      setPublishYear(String(journal.publishYear || new Date().getFullYear()));
      
      const rM = getRomanMonth(journal.publishMonth);
      setRomanMonth(rM);

      // Default Letter Date formatted Indonesian
      const today = new Date();
      const monthsIndo = [
        "Januari", "Februari", "Maret", "April", "Mei", "Juni",
        "Juli", "Agustus", "September", "Oktober", "November", "Desember"
      ];
      setLetterDate(`Semarang, ${today.getDate()} ${monthsIndo[today.getMonth()]} ${today.getFullYear()}`);
      
      setApcAmount(journal.apcAmount || 150000);
      setPublicationType(journal.publicationType || "Reguler");
      setPaymentStatus(journal.payment || "Belum Bayar");
      setSignatoryName("Iwan Mahendro, S.Kom., M.Pd., M.Kom.");
    }
  }, [journal]);

  // Handle dynamic serial number computations
  useEffect(() => {
    if (journal) {
      const artNo = articleNumber || "-";
      const yr = publishYear || "-";
      if (docType === "loa") {
        setLetterNumber(`${artNo}/EBISMEN/FEB-AMNI/${romanMonth}/${yr}`);
      } else {
        setLetterNumber(`${artNo}/INV-EBISMEN/FEB-AMNI/${romanMonth}/${yr}`);
      }
    }
  }, [docType, articleNumber, romanMonth, publishYear, journal]);

  if (!isOpen || !journal) return null;

  // Render high-fidelity printing HTML block
  const generatePrintHTML = () => {
    const isLoa = docType === "loa";
    
    // Core document content templates based on user configurations
    const documentBodyHTML = isLoa ? `
      <p style="margin-bottom: 20px; line-height: 1.6; text-align: justify;">
        Kami beritahukan bahwa naskah ilmiah yang saudara/i kirimkan untuk diterbitkan pada jurnal EBISMEN (e-ISSN: 2962-7621; p-ISSN: 2962-763X) dengan judul:
      </p>
      <p style="text-align: center; margin: 25px 0; font-weight: bold; font-style: italic; line-height: 1.5; padding: 0 15px; font-size: 15px;">
        “${title}”
      </p>
      <p style="margin-bottom: 25px; line-height: 1.6; text-align: justify;">
        Berdasarkan hasil proses review dan editing, naskah tersebut dinyatakan <strong style="color: #000; text-decoration: underline;">DITERIMA</strong> dan akan dipublikasikan di jurnal <strong>EBISMEN Vol ${volume}. No. ${issueNumber}.</strong>
      </p>
      <p style="line-height: 1.6; text-align: justify; margin-bottom: 30px;">
        Demikian informasi yang dapat kami sampaikan, atas kerjasama dan perhatiannya, diucapkan terima kasih.
      </p>
    ` : `
      <p style="margin-bottom: 15px; line-height: 1.6; text-align: justify;">
        Kami kirimkan lembar tagihan biaya penerbitan artikel (Article Processing Charge / APC) untuk naskah ilmiah saudara/i yang akan diterbitkan pada jurnal EBISMEN (e-ISSN: 2962-7621; p-ISSN: 2962-763X) dengan judul:
      </p>
      <p style="text-align: center; margin: 15px 0; font-weight: bold; font-style: italic; line-height: 1.4; padding: 0 10px; font-size: 14px;">
        “${title}”
      </p>
      <p style="margin-bottom: 12px; line-height: 1.4; font-weight: bold;">
        Rincian administrasi administrasi publikasi Jurnal EBISMEN Vol ${volume}, No. ${issueNumber} adalah sebagai berikut:
      </p>
      <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 13.5px;">
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="padding: 6px 0; width: 35%; color: #475569;">Layanan Publikasi:</td>
          <td style="padding: 6px 0; font-weight: bold;">${publicationType}</td>
        </tr>
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="padding: 6px 0; color: #475569;">Jumlah APC Tagihan:</td>
          <td style="padding: 6px 0; font-weight: bold; color: #b91c1c;">Rp ${apcAmount.toLocaleString("id-ID")}</td>
        </tr>
        <tr style="border-bottom: 1px solid #e2e8f0;">
          <td style="padding: 6px 0; color: #475569;">Status Pembayaran:</td>
          <td style="padding: 6px 0; font-weight: bold; color: ${paymentStatus === "Sudah Bayar" ? "#047857" : "#b91c1c"};">${paymentStatus}</td>
        </tr>
      </table>
      <div style="background-color: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 8px; padding: 12px 16px; margin-bottom: 20px; font-size: 12.5px; line-height: 1.5;">
        <span style="font-weight: bold; display: block; margin-bottom: 4px; color: #1e3a8a;">Pusat Alokasi Pembayaran Rekening Redaksi:</span>
        • <strong>Bank Mandiri: 1360034498730</strong> (a.n Dhanan)<br/>
        • <strong>DANA: 089667747299</strong> (a.n Dhanan)<br/>
        <span style="font-style: italic; display: block; margin-top: 6px; color: #64748b;">Harap segera melampirkan konfirmasi struk transfer kepada tim editor via pesan WhatsApp agar status naskah diproses.</span>
      </div>
      <p style="line-height: 1.5; text-align: justify; margin-bottom: 20px;">
        Demikian lembar tagihan ini disampaikan, atas kerjasama dan perhatiannya, dewan redaksi mengucapkan terima kasih.
      </p>
    `;

    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>${isLoa ? "LoA" : "Invoice"} - ${authorName}</title>
          <style>
            @import url('https://fonts.googleapis.com/css2?family=Times+New+Roman&family=Inter:wght@400;500;700;800&display=swap');
            
            @page {
              size: A4;
              margin: 0;
            }
            body { 
              margin: 0; 
              padding: 0;
              background-color: #ffffff;
              font-family: 'Times New Roman', serif;
              color: #1e293b;
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
            }
            .a4-page {
              width: 210mm;
              height: 297mm;
              box-sizing: border-box;
              padding: 20mm 18mm 18mm 18mm;
              position: relative;
              background-color: #ffffff;
              overflow: hidden;
              display: flex;
              flex-direction: column;
              justify-content: space-between;
            }
            
            /* Letterhead Header Section */
            .header-container {
              display: flex;
              justify-content: space-between;
              align-items: center;
              padding-bottom: 12px;
              position: relative;
            }
            .header-left-badges {
              display: flex;
              align-items: center;
              gap: 8px;
            }
            .cc-badge {
              height: 25px;
              width: auto;
            }
            .open-access {
              height: 24px;
              color: #f4h;
            }
            .ebismen-block {
              display: flex;
              flex-direction: column;
              background-color: #8b0000;
              color: #ffffff;
              padding: 5px 8px;
              border-radius: 2px;
              font-family: 'Inter', sans-serif;
              text-align: center;
            }
            .ebismen-title {
              font-weight: 900;
              font-size: 13px;
              line-height: 1;
              letter-spacing: -0.5px;
            }
            .ebismen-subtitle {
              font-size: 5px;
              letter-spacing: 0.3px;
              text-transform: uppercase;
              font-weight: 500;
              line-height: 1;
              margin-top: 2px;
            }
            .sinta-badge {
              display: flex;
              border: 1px solid #1e488f;
              border-radius: 3px;
              overflow: hidden;
              font-family: 'Inter', sans-serif;
              font-size: 8.5px;
            }
            .sinta-left {
              background-color: #1e488f;
              color: #ffffff;
              font-weight: bold;
              padding: 2px 5px;
              text-transform: uppercase;
            }
            .sinta-right {
              background-color: #f8fafc;
              color: #1e488f;
              font-weight: 800;
              padding: 2px 5.5px;
            }
            
            .header-right-text {
              text-align: right;
              font-family: 'Inter', sans-serif;
              font-size: 9px;
              color: #0f172a;
              line-height: 1.4;
            }
            .header-bold-gray {
              font-weight: 700;
            }
            .header-muted {
              color: #334155;
            }
            
            /* Divider lines */
            .divider-lines {
              margin-top: 5px;
              margin-bottom: 25px;
              position: relative;
            }
            .divider-crimson {
              height: 3.5px;
              background-color: #8b0000;
            }
            .divider-black {
              height: 1px;
              background-color: #0f172a;
              margin-top: 1.5px;
            }

            /* Watermark background */
            .watermark-wrapper {
              position: absolute;
              top: 50%;
              left: 50%;
              transform: translate(-50%, -50%) rotate(-15deg);
              opacity: 0.05;
              font-size: 130px;
              font-family: 'Inter', sans-serif;
              font-weight: 900;
              letter-spacing: 12px;
              color: #8b0000;
              text-transform: uppercase;
              pointer-events: none;
              user-select: none;
              z-index: 0;
              text-align: center;
              white-space: nowrap;
            }
            .watermark-subtext {
              font-size: 16px;
              letter-spacing: 4px;
              display: block;
              margin-top: -15px;
            }

            /* Main document wrapper */
            .letter-content {
              position: relative;
              z-index: 10;
              flex-grow: 1;
              display: flex;
              flex-direction: column;
            }

            /* Title Block */
            .doc-title-block {
              text-align: center;
              margin-bottom: 28px;
            }
            .doc-title-main {
              font-size: 18.5px;
              font-weight: bold;
              text-decoration: underline;
              text-transform: uppercase;
              margin: 0;
              letter-spacing: 0.2px;
            }
            .doc-title-number {
              font-size: 14.5px;
              margin: 6px 0 0 0;
            }

            /* Address Recipient block */
            .recipient-block {
              margin-bottom: 25px;
              line-height: 1.5;
              font-size: 14.5px;
            }
            .recipient-detail {
              font-weight: bold;
              margin-left: 0;
            }
            .recipient-tab {
              margin-left: 60px;
            }

            /* Document text block */
            .body-text-block {
              font-size: 14.5px;
              color: #0f172a;
            }

            /* Signature Stamp block */
            .signature-container {
              align-self: flex-end;
              width: 250px;
              margin-top: auto;
              padding-top: 20px;
              font-size: 14px;
              line-height: 1.4;
              position: relative;
            }
            .signature-date {
              margin-bottom: 4px;
            }
            .signature-role {
              margin-bottom: 12px;
            }
            
            /* Administrative Stamp graphic replica */
            .stamp-area {
              height: 100px;
              position: relative;
              display: flex;
              align-items: center;
              margin-left: -20px;
            }
            .stamp-replica {
              position: absolute;
              width: 170px;
              height: 86px;
              border: 3px solid rgba(220, 38, 38, 0.75);
              border-radius: 4px;
              transform: rotate(-3deg);
              display: flex;
              flex-direction: column;
              justify-content: space-between;
              padding: 4px;
              box-sizing: border-box;
              background-color: rgba(255, 255, 255, 0.1);
            }
            .stamp-header {
              color: rgba(220, 38, 38, 0.75);
              font-family: 'Inter', sans-serif;
              font-weight: 900;
              font-size: 7px;
              text-align: center;
              letter-spacing: 0.3px;
              border-bottom: 1px solid rgba(220, 38, 38, 0.35);
              padding-bottom: 2px;
              line-height: 1;
            }
            .stamp-middle {
              display: flex;
              justify-content: space-between;
              align-items: center;
              color: rgba(220, 38, 38, 0.85);
              font-family: 'Inter', sans-serif;
              font-weight: 900;
              font-size: 11px;
              padding: 0 4px;
            }
            .stamp-footer {
              color: rgba(220, 38, 38, 0.75);
              font-family: 'Inter', sans-serif;
              font-weight: 900;
              font-size: 6.5px;
              text-align: center;
              letter-spacing: 0.3px;
              border-top: 1px solid rgba(220, 38, 38, 0.35);
              padding-top: 2px;
              line-height: 1;
            }
            .qr-overlay {
              position: absolute;
              left: 55px;
              top: 10px;
              width: 65px;
              height: 65px;
              background-color: #ffffff;
              padding: 3px;
              border: 1px solid #cbd5e1;
              box-sizing: border-box;
              border-radius: 2px;
              z-index: 20;
            }
            .qr-svg {
              width: 100%;
              height: 100%;
              color: #0f172a;
            }

            .signatory-name {
              font-weight: bold;
              border-bottom: 1px solid #1e293b;
              display: inline-block;
              margin-top: 12px;
              font-size: 14.5px;
            }

            /* Footer area */
            .footer-section {
              margin-top: auto;
              padding-top: 20px;
            }
            .footer-divider-black {
              height: 1px;
              background-color: #0f172a;
              margin-bottom: 1.5px;
            }
            .footer-divider-crimson {
              height: 3.5px;
              background-color: #8b0000;
              margin-bottom: 10px;
            }
            .footer-grid {
              display: flex;
              justify-content: space-between;
              align-items: flex-end;
              font-family: 'Inter', sans-serif;
              font-size: 8.5px;
              color: #334155;
            }
            .footer-left {
              line-height: 1.5;
            }
            .footer-link {
              color: #1d4ed8;
              text-decoration: underline;
            }
            .footer-right-barcode {
              text-align: right;
              display: flex;
              flex-direction: column;
              align-items: flex-end;
              gap: 2px;
            }
            .barcode-svg {
              height: 28px;
              width: auto;
            }
            .barcode-num {
              font-size: 8px;
              letter-spacing: 1.8px;
              font-[#1e293b];
              margin-right: 3px;
            }
          </style>
        </head>
        <body>
          <div class="a4-page">
            
            <!-- Watermark -->
            <div class="watermark-wrapper">
              EBISMEN
              <span class="watermark-subtext">Jurnal Ekonomi Bisnis dan Manajemen</span>
            </div>

            <!-- Top Header -->
            <div class="header-container">
              <div class="header-left-badges">
                <!-- Direct CC BY-SA Image badge -->
                <img src="https://mirrors.creativecommons.org/presskit/buttons/88x31/png/by-sa.png" alt="CC BY-SA" class="cc-badge" />
                
                <!-- Open Access Lock SVG Icon -->
                <svg viewBox="0 0 24 24" class="open-access" style="width: 18px; height: 18px; fill: #f49c00;">
                  <path d="M12 17c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm6-9h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v1.9H6c-1.1 0-2 .9-2 2 v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6-5c1.66 0 3 1.34 3 3v2H9V6c0-1.66 1.34-3 3-3z"/>
                </svg>

                <!-- EBISMEN Badge -->
                <div class="ebismen-block">
                  <span class="ebismen-title">EBISMEN</span>
                  <span class="ebismen-subtitle">Jurnal Ekonomi Bisnis dan Manajemen</span>
                </div>

                <!-- SINTA 4 Badge -->
                <div class="sinta-badge">
                  <div class="sinta-left">Accredited</div>
                  <div class="sinta-right">SINTA 4</div>
                </div>
              </div>

              <div class="header-right-text">
                <span class="header-bold-gray">e-ISSN: 2962-7621; p-ISSN: 2962-763X</span><br/>
                <span class="header-muted">DOI: https://doi.org/10.58192/ebismen</span><br/>
                <span>Fakultas Ekonomi dan Bisnis</span><br/>
                <span>Universitas Maritim AMNI Semarang</span>
              </div>
            </div>

            <!-- Double Horizontal Rule Line -->
            <div class="divider-lines">
              <div class="divider-crimson"></div>
              <div class="divider-black"></div>
            </div>

            <!-- Main Documentation Layout -->
            <div class="letter-content">
              
              <!-- Center Title Header -->
              <div class="doc-title-block">
                <h1 class="doc-title-main">${isLoa ? "LoA (Letter of Acceptance)" : "INVOICE PUBLIKASI"}</h1>
                <p class="doc-title-number">Nomor: ${letterNumber}</p>
              </div>

              <!-- Recipient Addresses -->
              <div class="recipient-block">
                Kepada Yth.<br/>
                Sdr/i:<br/>
                <span class="recipient-detail">${authorName}</span><br/>
                <span class="header-muted">${affiliation}</span><br/>
                Di<br/>
                <span class="recipient-tab">Tempat</span>
              </div>

              <!-- Content body -->
              <div class="body-text-block">
                ${documentBodyHTML}
              </div>

              <!-- Dynamic Signature Sign block -->
              <div class="signature-container">
                <div class="signature-date">${letterDate}</div>
                <div class="signature-role">Editor Jurnal EBISMEN</div>
                
                <!-- EBISMEN stamps and QR overlay -->
                <div class="stamp-area">
                  <div class="stamp-replica">
                    <div class="stamp-header">LPPM UNIVERSITAS MARITIM AMNI</div>
                    <div class="stamp-middle">
                      <span>JURNAL</span>
                      <span>EBISMEN</span>
                    </div>
                    <div class="stamp-footer">SEMARANG - INDONESIA</div>
                  </div>
                  <div class="qr-overlay">
                    <svg viewBox="0 0 29 29" class="qr-svg">
                      <path fill="currentColor" d="M0 0h7v7H0zm1 1h5v5H1zm1 1h3v3H2zm6-2h1v1H8zm1 1h1v1H9zm1-1h1v1h-1zm3-1h7v7h-7zm1 1h5v5h-5zm1 1h3v3h-2zm-6 4h1v1H8zm1 1h1v1H9zm-5 4h1v1H4zm1 1h1v1H5zm6-6h1v1h-1zm3 1h1v1h-1zm1-1h1v1h-1zm4 1h1v1h-1zm-9 3h1v1H8zm1 1h2v1H9zm2-1h1v1h-1zm3 0h1v1h-1zm1 1h1v1h-1zm1-1h2v1h-2zm-7 4h1v1H8zm1 1h1v1H9zm1-1h1v1h-1zm3-1h1v1h-1zm1 1h1v1h-1zm1-1h1v1h-1zm3 0h1v1h-1zm-13 4v-7h7v7zm1-6h5v5H1zm1 1h3v3H2zm6 2h1v1H8zm1 1h1v1H9zm1-1h1v1h-1zm3-1h1v1h-1zm1 1h1v1h-1zm1-1h2v1h-2zm5 1h1v1h-1zm-9 3h1v1H8zm1 1h2v1H9zm2-1h1v1h-1zm3 0h1v1h-1zm1 1h1v1h-1zm1-1h2v1h-2z" />
                    </svg>
                  </div>
                </div>

                <div class="signatory-name">${signatoryName}</div>
              </div>

            </div>

            <!-- Footer block with address and crisp SVG barcode -->
            <div class="footer-section">
              <div class="footer-divider-black"></div>
              <div class="footer-divider-crimson"></div>
              <div class="footer-grid">
                <div class="footer-left">
                  Jl. Soekarno Hatta No.180, Palebon, Kec. Pedurungan,<br/>
                  Kota Semarang, Jawa Tengah 50246<br/>
                  Email: <span class="footer-link">ebismenamni@gmail.com</span> | <span class="footer-link">lppm.amni@gmail.com</span>
                </div>
                <div class="footer-right-barcode">
                  <svg viewBox="0 0 120 30" width="112" height="28" class="barcode-svg">
                    <rect width="120" height="30" fill="white" />
                    <rect x="5" y="0" width="2" height="26" fill="black" />
                    <rect x="9" y="0" width="1" height="26" fill="black" />
                    <rect x="12" y="0" width="3" height="26" fill="black" />
                    <rect x="17" y="0" width="1" height="26" fill="black" />
                    <rect x="19" y="0" width="2" height="26" fill="black" />
                    <rect x="23" y="0" width="4" height="26" fill="black" />
                    <rect x="29" y="0" width="1" height="26" fill="black" />
                    <rect x="31" y="0" width="2" height="26" fill="black" />
                    <rect x="35" y="0" width="1" height="26" fill="black" />
                    <rect x="38" y="0" width="3" height="26" fill="black" />
                    <rect x="43" y="0" width="1" height="26" fill="black" />
                    <rect x="45" y="0" width="2" height="26" fill="black" />
                    <rect x="49" y="0" width="4" height="26" fill="black" />
                    <rect x="55" y="0" width="2" height="26" fill="black" />
                    <rect x="59" y="0" width="1" height="26" fill="black" />
                    <rect x="62" y="0" width="3" height="26" fill="black" />
                    <rect x="67" y="0" width="1" height="26" fill="black" />
                    <rect x="70" y="0" width="2" height="26" fill="black" />
                    <rect x="74" y="0" width="4" height="26" fill="black" />
                    <rect x="80" y="0" width="1" height="26" fill="black" />
                    <rect x="83" y="0" width="3" height="26" fill="black" />
                    <rect x="88" y="0" width="1" height="26" fill="black" />
                    <rect x="90" y="0" width="2" height="26" fill="black" />
                    <rect x="94" y="0" width="3" height="26" fill="black" />
                    <rect x="99" y="0" width="1" height="26" fill="black" />
                    <rect x="102" y="0" width="4" height="26" fill="black" />
                    <rect x="108" y="0" width="2" height="26" fill="black" />
                    <rect x="112" y="0" width="2" height="26" fill="black" />
                    <rect x="115" y="0" width="1" height="26" fill="black" />
                  </svg>
                  <div class="barcode-num">9&nbsp;&nbsp;772962&nbsp;&nbsp;&nbsp;762005</div>
                </div>
              </div>
            </div>

          </div>
        </body>
      </html>
    `;
  };

  // Launch clean native print dialogue inside isolated frame
  const handlePrint = () => {
    const html = generatePrintHTML();
    
    const iframe = document.createElement("iframe");
    iframe.style.position = "absolute";
    iframe.style.width = "0px";
    iframe.style.height = "0px";
    iframe.style.border = "none";
    document.body.appendChild(iframe);

    const doc = iframe.contentWindow?.document;
    if (doc) {
      doc.open();
      doc.write(html);
      doc.close();

      // Trigger native dialogue once frame finishes loading completely
      setTimeout(() => {
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();
        setTimeout(() => {
          document.body.removeChild(iframe);
        }, 1000);
      }, 500);
    }
  };

  const copyRedaksionalText = () => {
    const isLoa = docType === "loa";
    let text = "";
    if (isLoa) {
      text = `SURAT PERNYATAAN PENERIMAAN (LoA)
Nomor: ${letterNumber}

Kepada Yth.
Sdr/i: ${authorName}
${affiliation}
Di Tempat

Kami beritahukan bahwa naskah ilmiah yang saudara/i kirimkan untuk diterbitkan pada jurnal EBISMEN (e-ISSN: 2962-7621; p-ISSN: 2962-763X) dengan judul:
“${title}”

Berdasarkan hasil proses review dan editing, naskah tersebut dinyatakan DITERIMA dan akan dipublikasikan di jurnal EBISMEN Vol ${volume}. No. ${issueNumber}.

Demikian informasi yang dapat kami sampaikan, atas kerjasama dan perhatiannya, diucapkan terima kasih.

${letterDate}
Editor Jurnal EBISMEN`;
    } else {
      text = `INVOICE TAGIHAN PUBLIKASI (APC)
Nomor: ${letterNumber}

Kepada Yth.
Sdr/i: ${authorName}
${affiliation}
Di Tempat

Kami kirimkan lembar tagihan biaya penerbitan artikel (Article Processing Charge / APC) untuk naskah ilmiah saudara/i yang akan diterbitkan pada jurnal EBISMEN (e-ISSN: 2962-7621; p-ISSN: 2962-763X) dengan judul:
“${title}”

Rincian Tagihan APC Publikasi Jurnal EBISMEN Vol ${volume}, No. ${issueNumber}:
• Layanan Publikasi: ${publicationType}
• Jumlah Tagihan: Rp ${apcAmount.toLocaleString("id-ID")}
• Status Pembayaran: ${paymentStatus}

Pembayaran dapat ditransfer melalui rekening perwakilan dewan redaksi berikut:
- Bank Mandiri: 1360034498730 (a.n Dhanan)
- DANA: 089667747299 (a.n Dhanan)

Mohon lampirkan kiriman konfirmasi struk pembayaran Anda setelah selesai mentransfernya kepada kami. Terima kasih.

${letterDate}
Editor Jurnal EBISMEN`;
    }

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isLoa = docType === "loa";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop blur overlay */}
      <div 
        className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs transition-all pointer-events-auto" 
        onClick={onClose}
      />

      {/* Main Container Dual-Pane Frame */}
      <div className="relative bg-slate-100 rounded-3xl shadow-2xl w-full max-w-6xl max-h-[92vh] flex flex-col md:flex-row border border-slate-200 overflow-hidden animate-scale-up z-10 leading-relaxed font-sans text-slate-900">
        
        {/* Left Control Panel / Field Edits */}
        <div className="w-full md:w-[38%] bg-white border-r border-slate-200 flex flex-col max-h-full">
          
          {/* Header Controls Segment */}
          <div className="p-5 border-b border-slate-100 bg-slate-50/50 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold tracking-tight text-slate-800 flex items-center gap-2">
                <FileText className="w-4.5 h-4.5 text-indigo-600" />
                Draf Dokumen Jurnal
              </h3>
              <p className="text-[10px] text-slate-400 font-semibold mt-0.5 uppercase tracking-wide">Pusat Cetak & Penyesuaian Data</p>
            </div>
            <button 
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Segment Toggle */}
          <div className="px-5 pt-4 pb-1">
            <div className="grid grid-cols-2 p-1 bg-slate-100 rounded-xl">
              <button
                type="button"
                onClick={() => setDocType("loa")}
                className={`py-2 text-[11px] font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                  isLoa 
                    ? "bg-white text-indigo-700 shadow-xs" 
                    : "text-slate-500 hover:text-slate-700"
                }`}
              >
                <Award className="w-3.5 h-3.5" /> Letter of Acceptance
              </button>
              <button
                type="button"
                onClick={() => setDocType("invoice")}
                className={`py-2 text-[11px] font-bold rounded-lg transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
                  !isLoa 
                    ? "bg-white text-indigo-700 shadow-xs" 
                    : "text-slate-500 hover:text-slate-700"
                }`}
              >
                <DollarSign className="w-3.5 h-3.5" /> Invoice Publikasi
              </button>
            </div>
          </div>

          {/* Dynamic Forms Sidebar (Scrollable) */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4 max-h-[500px] md:max-h-none">
            
            {/* Meta input Section 1 */}
            <div className="bg-slate-50/50 p-4 rounded-2xl border border-slate-150 space-y-3.5">
              <h4 className="text-[10px] uppercase tracking-wider font-extrabold text-indigo-600 flex items-center gap-1.5 border-b border-slate-200 pb-1.5">
                <Hash className="w-3.5 h-3.5" /> Parameter & Penomoran
              </h4>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">No. Artikel (ID)</label>
                  <input 
                    type="text" 
                    value={articleNumber} 
                    onChange={(e) => setArticleNumber(e.target.value)} 
                    className="mt-1 block w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-800 focus:border-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider font-display">Bulan Terbit (Romawi)</label>
                  <select
                    value={romanMonth}
                    onChange={(e) => setRomanMonth(e.target.value)}
                    className="mt-1 block w-full rounded-lg border border-slate-200 bg-white px-2.5 py-[7px] text-xs text-slate-800 focus:border-indigo-500 focus:outline-none font-mono"
                  >
                    {["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"].map(m => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Volume Jurnal</label>
                  <input 
                    type="text" 
                    value={volume} 
                    onChange={(e) => setVolume(e.target.value)} 
                    className="mt-1 block w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-800 focus:border-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">No. Issue Jurnal</label>
                  <input 
                    type="text" 
                    value={issueNumber} 
                    onChange={(e) => setIssueNumber(e.target.value)} 
                    className="mt-1 block w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-800 focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider font-display">Tahun Terbit</label>
                  <input 
                    type="text" 
                    value={publishYear} 
                    onChange={(e) => setPublishYear(e.target.value)} 
                    className="mt-1 block w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-800 focus:border-indigo-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider font-display">Tanggal Surat</label>
                  <input 
                    type="text" 
                    value={letterDate} 
                    onChange={(e) => setLetterDate(e.target.value)} 
                    className="mt-1 block w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-800 focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>
            </div>

            {/* Recipient info section 2 */}
            <div className="bg-slate-50/50 p-4 rounded-2xl border border-slate-150 space-y-3">
              <h4 className="text-[10px] uppercase tracking-wider font-extrabold text-indigo-600 flex items-center gap-1.5 border-b border-slate-200 pb-1.5">
                <User className="w-3.5 h-3.5" /> Nama & Afiliasi Penulis
              </h4>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Penulis Surat</label>
                <input 
                  type="text" 
                  value={authorName} 
                  onChange={(e) => setAuthorName(e.target.value)} 
                  className="mt-1 block w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-800 focus:border-indigo-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Afiliasi Penulis</label>
                <input 
                  type="text" 
                  value={affiliation} 
                  onChange={(e) => setAffiliation(e.target.value)} 
                  className="mt-1 block w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-800 focus:border-indigo-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Content Details section 3 */}
            <div className="bg-slate-50/50 p-4 rounded-2xl border border-slate-150 space-y-3">
              <h4 className="text-[10px] uppercase tracking-wider font-extrabold text-indigo-600 flex items-center gap-1.5 border-b border-slate-200 pb-1.5">
                <Type className="w-3.5 h-3.5" /> Judul Naskah Ilmiah
              </h4>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Judul Naskah</label>
                <textarea 
                  rows={3}
                  value={title} 
                  onChange={(e) => setTitle(e.target.value)} 
                  className="mt-1 block w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-800 focus:border-indigo-500 focus:outline-none leading-relaxed"
                />
              </div>
            </div>

            {/* Custom Payment Details - ONLY IF INVOICE */}
            {!isLoa && (
              <div className="bg-slate-50/50 p-4 rounded-2xl border border-slate-150 space-y-3.5 animate-slide-in">
                <h4 className="text-[10px] uppercase tracking-wider font-extrabold text-[#10b981] flex items-center gap-1.5 border-b border-slate-200 pb-1.5">
                  <DollarSign className="w-3.5 h-3.5" /> Administrasi Invoice
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Jumlah APC (Rp)</label>
                    <input 
                      type="number" 
                      value={apcAmount} 
                      onChange={(e) => setApcAmount(Number(e.target.value) || 0)} 
                      className="mt-1 block w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-800 focus:border-indigo-500 focus:outline-none font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Prosedur Rilis</label>
                    <select
                      value={publicationType}
                      onChange={(e) => setPublicationType(e.target.value)}
                      className="mt-1 block w-full rounded-lg border border-slate-200 bg-white px-2.5 py-[7px] text-xs text-slate-800 focus:border-indigo-500 focus:outline-none"
                    >
                      <option value="Reguler">Reguler</option>
                      <option value="Fast Track">Fast Track</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Status Pembayaran</label>
                  <select
                    value={paymentStatus}
                    onChange={(e) => setPaymentStatus(e.target.value)}
                    className="mt-1 block w-full rounded-lg border border-slate-200 bg-white px-2.5 py-[7px] text-xs text-slate-800 focus:border-indigo-500 focus:outline-none"
                  >
                    <option value="Belum Bayar">Belum Bayar</option>
                    <option value="Sudah Bayar">Sudah Bayar</option>
                  </select>
                </div>
              </div>
            )}

            {/* General signatory tuning */}
            <div className="bg-slate-50/50 p-4 rounded-2xl border border-slate-150 space-y-3">
              <h4 className="text-[10px] uppercase tracking-wider font-extrabold text-indigo-600 flex items-center gap-1.5 border-b border-slate-200 pb-1.5">
                <span>✒️</span> Tanda Tangan Editor
              </h4>
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">Nama Editor in Chief</label>
                <input 
                  type="text" 
                  value={signatoryName} 
                  onChange={(e) => setSignatoryName(e.target.value)} 
                  className="mt-1 block w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-800 focus:border-indigo-500 focus:outline-none"
                />
              </div>
            </div>

          </div>

          {/* Core Sidebar control buttons footer */}
          <div className="p-5 border-t border-slate-100 bg-slate-50 flex gap-2.5 items-center justify-end">
            <button
              type="button"
              onClick={copyRedaksionalText}
              className={`px-4 py-2.5 rounded-xl border font-bold text-xs select-none transition-all cursor-pointer flex items-center gap-1.5 ${
                copied 
                  ? "bg-emerald-50 border-emerald-200 text-emerald-700" 
                  : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50 hover:text-slate-800"
              }`}
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? "Copied!" : "Salin Teks"}
            </button>
            <button
              type="button"
              onClick={handlePrint}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 active:scale-97 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-1.5 select-none cursor-pointer"
            >
              <Printer className="w-4 h-4" /> Cetak ke PDF
            </button>
          </div>

        </div>

        {/* Right Panel / Vector Real-time Canvas Rendering Preview */}
        <div className="flex-1 bg-slate-500 overflow-y-auto p-6 flex justify-center items-start overflow-x-hidden min-h-[450px] md:min-h-0 relative">
          
          {/* Subtitle helper badge */}
          <div className="absolute top-4 left-4 bg-slate-900/60 backdrop-blur-md text-[#6cffb4] text-[9px] font-black uppercase tracking-widest px-3 py-1.5 rounded-full border border-white/10 select-none hidden md:block z-20">
            ● Real-Time vector preview (A4 format)
          </div>

          {/* Simulated A4 Paper Wrapper Sheet */}
          <div 
            id="a4-printed-paper"
            className="w-[210mm] min-h-[297mm] bg-white text-slate-800 shadow-2xl p-14 relative flex flex-col justify-between origin-top scale-[0.45] md:scale-[0.58] lg:scale-[0.70] xl:scale-[0.82] transition-transform select-none border border-slate-200 my-[-250px] md:my-[-140px] lg:my-[-70px] xl:my-0 rounded-sm font-serif"
          >
            
            {/* Background watermark overlay */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rotate-[-15deg] opacity-[0.055] font-sans font-black text-[120px] text-red-800 tracking-widest uppercase select-none pointer-events-none z-0 text-center whitespace-nowrap leading-none">
              EBISMEN
              <span className="block text-sm tracking-widest mt-[-10px]">Jurnal Ekonomi Bisnis dan Manajemen</span>
            </div>

            {/* Top Branding Section Header */}
            <div className="relative z-10">
              <div className="flex justify-between items-center pb-3">
                
                {/* Visual logos aligned to left of head */}
                <div className="flex items-center gap-2">
                  <img src="https://mirrors.creativecommons.org/presskit/buttons/88x31/png/by-sa.png" alt="CC BY-SA" className="h-[21px] w-auto shrink-0 select-none" />
                  
                  {/* Lock graphic SVG */}
                  <svg viewBox="0 0 24 24" className="h-4.5 w-auto shrink-0 text-[#f49c00] fill-current">
                    <path d="M12 17c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm6-9h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v1.9H6c-1.1 0-2 .9-2 2 v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6-5c1.66 0 3 1.34 3 3v2H9V6c0-1.66 1.34-3 3-3z"/>
                  </svg>

                  {/* Red EBISMEN custom logo Block */}
                  <div className="flex flex-col bg-[#8b0000] text-white px-2 py-1 rounded-[1.5px] leading-none shrink-0 text-center select-none font-sans">
                    <span className="font-extrabold text-[11px] uppercase tracking-tight font-display">EBISMEN</span>
                    <span className="text-[4px] uppercase tracking-wider font-medium mt-0.5">Jurnal Ekonomi Bisnis dan Manajemen</span>
                  </div>

                  {/* SINTA 4 Badge container */}
                  <div className="flex border border-[#1e488f] rounded-[2.5px] overflow-hidden text-[7.5px] font-sans h-4 select-none shrink-0 bg-white">
                    <div className="bg-[#1e488f] text-white font-bold px-1.5 flex items-center justify-center uppercase leading-none">Accredited</div>
                    <div className="text-[#1e488f] font-black px-1.5 flex items-center justify-center bg-slate-50 leading-none">SINTA 4</div>
                  </div>
                </div>

                {/* Typography metadata info text to right of head */}
                <div className="text-right text-[8px] font-sans text-slate-900 leading-[1.3] shrink-0">
                  <span className="font-bold">e-ISSN: 2962-7621; p-ISSN: 2962-763X</span><br/>
                  <span className="text-slate-600">DOI: https://doi.org/10.58192/ebismen</span><br/>
                  <span>Fakultas Ekonomi dan Bisnis</span><br/>
                  <span>Universitas Maritim AMNI Semarang</span>
                </div>

              </div>

              {/* Red-black Horizontal rules header divider logo */}
              <div className="relative">
                <div className="h-[3px] bg-[#8b0000] w-full" />
                <div className="h-[0.8px] bg-slate-950 w-full mt-[1.5px]" />
              </div>
            </div>

            {/* Document Content Workspace Block */}
            <div className="relative z-10 flex-grow mt-8 flex flex-col">
              
              {/* Center Title header */}
              <div className="text-center mb-8">
                <h2 className="text-[17px] font-bold text-slate-950 underline uppercase tracking-wide leading-none">
                  {isLoa ? "LoA (Letter of Acceptance)" : "INVOICE PUBLIKASI"}
                </h2>
                <p className="text-[13px] text-slate-800 font-bold mt-2 leading-none">
                  Nomor: {letterNumber}
                </p>
              </div>

              {/* Recipient Addresses details block */}
              <div className="text-[13.5px] text-slate-900 leading-[1.45] mb-6">
                Kepada Yth.<br/>
                Sdr/i:<br/>
                <span className="font-bold text-slate-950 block">{authorName}</span>
                <span className="text-slate-600 block">{affiliation}</span>
                Di<br/>
                <span className="pl-14 block">Tempat</span>
              </div>

              {/* Core responsive editorial wording block */}
              <div className="text-[13.5px] text-slate-950 leading-[1.6] space-y-4">
                
                {isLoa ? (
                  <>
                    <p className="text-justify">
                      Kami beritahukan bahwa naskah ilmiah yang saudara/i kirimkan untuk diterbitkan pada jurnal EBISMEN (e-ISSN: 2962-7621; p-ISSN: 2962-763X) dengan judul:
                    </p>
                    <p className="text-center font-bold italic py-2 px-4 max-w-lg mx-auto leading-[1.5]">
                      “{title}”
                    </p>
                    <p className="text-justify">
                      Berdasarkan hasil proses review dan editing, naskah tersebut dinyatakan <span className="underline font-bold">DITERIMA</span> dan akan dipublikasikan di jurnal <strong className="text-slate-900">EBISMEN Vol {volume}. No. {issueNumber}.</strong>
                    </p>
                    <p className="text-justify pt-1">
                      Demikian informasi yang dapat kami sampaikan, atas kerjasama dan perhatiannya, diucapkan terima kasih.
                    </p>
                  </>
                ) : (
                  <>
                    <p className="text-justify">
                      Kami kirimkan lembar tagihan biaya penerbitan artikel (Article Processing Charge / APC) untuk naskah ilmiah saudara/i yang akan diterbitkan pada jurnal EBISMEN (e-ISSN: 2962-7621; p-ISSN: 2962-763X) dengan judul:
                    </p>
                    <p className="text-center font-bold italic py-1 px-4 max-w-lg mx-auto leading-[1.4] text-[13px]">
                      “{title}”
                    </p>
                    <p className="font-bold text-[13px] pt-1">
                      Rincian administrasi biaya publikasi Jurnal EBISMEN Vol {volume}, No. {issueNumber} adalah sebagai berikut:
                    </p>
                    
                    <div className="border border-slate-200 rounded-lg overflow-hidden bg-slate-50/20 text-xs font-sans max-w-md">
                      <div className="flex border-b border-slate-150 px-3 py-1.5 justify-between">
                        <span className="text-slate-500 font-medium">Layanan Publikasi:</span>
                        <span className="font-bold text-slate-900">{publicationType}</span>
                      </div>
                      <div className="flex border-b border-slate-150 px-3 py-1.5 justify-between">
                        <span className="text-slate-500 font-medium">Jumlah APC Tagihan:</span>
                        <span className="font-extrabold text-[#b91c1c] font-mono">Rp {apcAmount.toLocaleString("id-ID")}</span>
                      </div>
                      <div className="flex px-3 py-1.5 justify-between">
                        <span className="text-slate-500 font-medium">Status Pembayaran:</span>
                        <span className={`font-bold ${paymentStatus === "Sudah Bayar" ? "text-emerald-700" : "text-[#b91c1c]"}`}>{paymentStatus}</span>
                      </div>
                    </div>

                    <div className="bg-slate-50 border border-slate-205 border-dashed rounded-xl p-3.5 leading-[1.4] text-[11.5px] font-sans text-slate-800">
                      <span className="font-bold text-[#1e3a8a] block mb-1">Pusat Alokasi Pembayaran Rekening Redaksi:</span>
                      • <strong>Bank Mandiri: 1360034498730</strong> (a.n Dhanan)<br/>
                      • <strong>DANA: 089667747299</strong> (a.n Dhanan)<br/>
                      <span className="text-[10px] text-slate-500 mt-1.5 block italic leading-normal">Mohon lampirkan struk transfer Anda setelah pembayaran berhasil kepada editor.</span>
                    </div>

                    <p className="text-justify text-[13px]">
                      Demikian tagihan ini disampaikan, atas perhatian dewan redaksi mengucapkan terima kasih.
                    </p>
                  </>
                )}

              </div>

              {/* Stamp and official Semarang signature graphic overlay block */}
              <div className="self-end w-[220px] pt-10 text-[13px] leading-tight relative mt-auto">
                <div className="text-slate-900">{letterDate}</div>
                <div className="text-slate-605 mt-1">Editor Jurnal EBISMEN</div>
                
                {/* LPPM Stamp and QR Overlay layout details */}
                <div className="h-[95px] relative flex items-center ml-[-15px] select-none pointer-events-none">
                  
                  {/* Administrative red stamp outline */}
                  <div className="absolute w-[150px] h-[78px] border-3 rounded border-red-500/80 rotate-[-3deg] flex flex-col justify-between p-1 z-10 select-none">
                    <div className="text-[6.5px] font-black tracking-wider text-red-500/80 text-center font-sans uppercase leading-none border-b border-red-500/30 pb-1">
                      LPPM UNIVERSITAS MARITIM AMNI
                    </div>
                    <div className="flex justify-between items-center text-[10px] font-extrabold text-red-600/80 px-1 font-sans leading-none my-1">
                      <span>JURNAL</span>
                      <span>EBISMEN</span>
                    </div>
                    <div className="text-[5.5px] font-black tracking-wider text-red-500/80 text-center font-sans uppercase leading-none border-t border-red-500/30 pt-1">
                      SEMARANG - INDONESIA
                    </div>
                  </div>

                  {/* QR code card verifying integrity */}
                  <div className="absolute left-[46px] top-[9px] w-[58px] h-[58px] bg-white p-[2.5px] border border-slate-250 shadow-sm rounded-xs select-none z-20">
                    <svg viewBox="0 0 29 29" className="w-full h-full text-slate-900 leading-none">
                      <path fill="currentColor" d="M0 0h7v7H0zm1 1h5v5H1zm1 1h3v3H2zm6-2h1v1H8zm1 1h1v1H9zm1-1h1v1h-1zm3-1h7v7h-7zm1 1h5v5h-5zm1 1h3v3h-2zm-6 4h1v1H8zm1 1h1v1H9zm-5 4h1v1H4zm1 1h1v1H5zm6-6h1v1h-1zm3 1h1v1h-1zm1-1h1v1h-1zm4 1h1v1h-1zm-9 3h1v1H8zm1 1h2v1H9zm2-1h1v1h-1zm3 0h1v1h-1zm1 1h1v1h-1zm1-1h2v1h-2zm-7 4h1v1H8zm1 1h1v1H9zm1-1h1v1h-1zm3-1h1v1h-1zm1 1h1v1h-1zm1-1h1v1h-1zm3 0h1v1h-1zm-13 4v-7h7v7zm1-6h5v5H1zm1 1h3v3H2zm6-2h1v1H8zm1 1h1v1H9zm1-1h1v1h-1zm3-1h1v1h-1zm1 1h1v1h-1zm1-1h2v1h-2zm5 1h1v1h-1zm-9 3h1v1H8zm1 1h2v1H9zm2-1h1v1h-1zm3 0h1v1h-1zm1 1h1v1h-1zm1-1h2v1h-2z" />
                    </svg>
                  </div>

                </div>

                <div className="font-bold border-b border-slate-900 inline-block text-[13.5px] font-sans tracking-wide mt-3 select-text">
                  {signatoryName}
                </div>
              </div>

            </div>

            {/* Bottom Footer block containing address maps details and barcode */}
            <div className="border-t border-slate-950 mt-auto pt-4 relative z-10">
              <div className="h-[2px] bg-[#8b0000] w-full mt-[-16px] mb-3" />
              <div className="flex justify-between items-end font-sans text-[7.5px] text-slate-500 leading-[1.45]">
                <div>
                  Jl. Soekarno Hatta No.180, Palebon, Kec. Pedurungan,<br/>
                  Kota Semarang, Jawa Tengah 50246<br/>
                  Email: <span className="text-[#1d4ed8]">ebismenamni@gmail.com</span> | <span className="text-[#1d4ed8]">lppm.amni@gmail.com</span>
                </div>
                
                {/* Barcode representation */}
                <div className="flex flex-col items-end gap-[1.5px] shrink-0 font-sans">
                  <svg viewBox="0 0 120 30" width="102" height="24" className="bg-white shrink-0">
                    <rect width="120" height="30" fill="white" />
                    <rect x="5" y="0" width="2" height="26" fill="black" />
                    <rect x="9" y="0" width="1" height="26" fill="black" />
                    <rect x="12" y="0" width="3" height="26" fill="black" />
                    <rect x="17" y="0" width="1" height="26" fill="black" />
                    <rect x="19" y="0" width="2" height="26" fill="black" />
                    <rect x="23" y="0" width="4" height="26" fill="black" />
                    <rect x="29" y="0" width="1" height="26" fill="black" />
                    <rect x="31" y="0" width="2" height="26" fill="black" />
                    <rect x="35" y="0" width="1" height="26" fill="black" />
                    <rect x="38" y="0" width="3" height="26" fill="black" />
                    <rect x="43" y="0" width="1" height="26" fill="black" />
                    <rect x="45" y="0" width="2" height="26" fill="black" />
                    <rect x="49" y="0" width="4" height="26" fill="black" />
                    <rect x="55" y="0" width="2" height="26" fill="black" />
                    <rect x="59" y="0" width="1" height="26" fill="black" />
                    <rect x="62" y="0" width="3" height="26" fill="black" />
                    <rect x="67" y="0" width="1" height="26" fill="black" />
                    <rect x="70" y="0" width="2" height="26" fill="black" />
                    <rect x="74" y="0" width="4" height="26" fill="black" />
                    <rect x="80" y="0" width="1" height="26" fill="black" />
                    <rect x="83" y="0" width="3" height="26" fill="black" />
                    <rect x="88" y="0" width="1" height="26" fill="black" />
                    <rect x="90" y="0" width="2" height="26" fill="black" />
                    <rect x="94" y="0" width="3" height="26" fill="black" />
                    <rect x="99" y="0" width="1" height="26" fill="black" />
                    <rect x="102" y="0" width="4" height="26" fill="black" />
                    <rect x="108" y="0" width="2" height="26" fill="black" />
                    <rect x="112" y="0" width="2" height="26" fill="black" />
                    <rect x="115" y="0" width="1" height="26" fill="black" />
                  </svg>
                  <div className="text-[7.2px] tracking-[1.4px] text-slate-800 mr-[3px] font-sans font-medium">9&nbsp;&nbsp;772962&nbsp;&nbsp;&nbsp;762005</div>
                </div>
              </div>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
}
