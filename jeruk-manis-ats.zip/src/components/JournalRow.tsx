/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Journal, ProcessStatus } from "../types";
import { STAGES } from "./ProgressIndicator";
import { 
  Edit2, 
  Trash2, 
  Phone, 
  Mail, 
  Award, 
  FileText, 
  CheckCircle2, 
  DollarSign, 
  Link, 
  ChevronDown, 
  ChevronUp, 
  AlertCircle,
  Clock,
  ExternalLink,
  MessageSquareShare,
  Printer
} from "lucide-react";

interface JournalRowProps {
  key?: string;
  journal: Journal;
  onEdit: () => void;
  onDelete: () => void;
  onQuickStatusChange: (newStatus: ProcessStatus) => void;
  onOpenUrlModal: (type: "publishedUrl" | "loaUrl" | "invoiceUrl") => void;
  onSendRevisionWhatsApp: () => void;
  onSendRevisionEmail: () => void;
  onSendLoaInvoiceWhatsApp: () => void;
  onSendLoaInvoiceEmail: () => void;
  onSendPublishWhatsApp: () => void;
  onSendPublishEmail: () => void;
  onGenerateDoc: (type: "loa" | "invoice") => void;
}

export function JournalRow({
  journal,
  onEdit,
  onDelete,
  onQuickStatusChange,
  onOpenUrlModal,
  onSendRevisionWhatsApp,
  onSendRevisionEmail,
  onSendLoaInvoiceWhatsApp,
  onSendLoaInvoiceEmail,
  onSendPublishWhatsApp,
  onSendPublishEmail,
  onGenerateDoc
}: JournalRowProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const deadlineDate = new Date(journal.deadline);
  const timeDiff = deadlineDate.getTime() - today.getTime();
  const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
  const isUrgent = daysDiff <= 2 && daysDiff >= 0 && journal.process !== "Publish";
  const isOverdue = daysDiff < 0 && journal.process !== "Publish";

  // Let's decide badges styling
  const getStatusBadgeStyle = (status: ProcessStatus) => {
    switch (status) {
      case "Belum submit": return "bg-gray-150 text-gray-700 border border-gray-200";
      case "Sudah disubmit": return "bg-blue-50 text-blue-700 border border-blue-200";
      case "Review": return "bg-amber-50 text-amber-800 border border-amber-200";
      case "Editing": return "bg-purple-50 text-purple-700 border border-purple-200";
      case "LoA sudah terbit": return "bg-cyan-50 text-cyan-700 border border-cyan-200";
      case "Publish": return "bg-green-50 text-green-700 border border-green-200";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getPaymentBadgeStyle = (p: string) => {
    return p === "Sudah Bayar" 
      ? "bg-green-50 text-green-700 border border-green-200" 
      : "bg-red-50 text-red-650 border border-red-200";
  };

  return (
    <React.Fragment>
      <tr className={`border-b border-slate-100 transition-colors hover:bg-indigo-55/15 ${isUrgent ? "bg-rose-50/20" : ""}`}>
        {/* Author Details Column */}
        <td className="px-5 py-4">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm ${
              isUrgent ? "bg-rose-100 text-rose-700 animate-pulse" : "bg-indigo-50 text-indigo-605"
            }`}>
              {journal.authorName.charAt(0).toUpperCase()}
            </div>
            <div>
              <div className="font-semibold text-slate-800 text-sm flex items-center gap-1.5">
                {journal.authorName}
                {isUrgent && (
                  <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-rose-100 text-rose-700 animate-bounce">
                    🚨 URGENT
                  </span>
                )}
              </div>
              <div className="text-xs text-slate-500 font-medium">{journal.affiliation}</div>
              <div className="text-[10px] text-slate-400 font-mono mt-0.5">{journal.email}</div>
            </div>
          </div>
        </td>

        {/* Title Details Column */}
        <td className="px-5 py-4 max-w-xs">
          <div className="text-sm font-medium text-slate-800 line-clamp-2" title={journal.title}>
            {journal.title}
          </div>
          <div className="flex items-center gap-2 mt-1.5">
            <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-mono">
              No: {journal.articleNumber || "-"}
            </span>
            <span className={`text-[10px] px-1.5 py-0.5 rounded font-semibold ${
              journal.publicationType === "Fast Track" ? "bg-purple-50 text-purple-700" : "bg-teal-50 text-teal-750"
            }`}>
              {journal.publicationType}
            </span>
          </div>
        </td>

        {/* Target Journal Column */}
        <td className="px-5 py-4 text-center">
          <span className="inline-block px-2.5 py-1 rounded-full text-xs font-bold bg-indigo-50 text-indigo-900 border border-indigo-100">
            {journal.journalTarget}
          </span>
          <div className="text-[10px] text-slate-400 mt-1 font-medium">
            Vol {journal.volume || "-"}, No {journal.issueNumber || "-"}
          </div>
        </td>

        {/* Deadline Column */}
        <td className="px-5 py-4">
          <div className="flex flex-col">
            <span className={`text-sm font-mono font-medium ${
              isUrgent ? "text-rose-700 font-bold" : isOverdue ? "text-rose-600 font-bold" : "text-slate-700"
            }`}>
              {journal.deadline}
            </span>
            {isUrgent ? (
              <span className="text-[10px] text-rose-800 font-semibold flex items-center gap-0.5 mt-0.5">
                <Clock className="w-3 h-3 text-rose-500 animate-spin" /> {daysDiff === 0 ? "Hari ini!" : `${daysDiff} hari lagi!`}
              </span>
            ) : isOverdue ? (
              <span className="text-[10px] text-rose-600 font-semibold mt-0.5 flex items-center gap-0.5">
                <AlertCircle className="w-3 h-3" /> Terlewat!
              </span>
            ) : (
              <span className="text-[10px] text-slate-400 mt-0.5">Sisa {daysDiff} hari</span>
            )}
          </div>
        </td>

        {/* Status Tracker State */}
        <td className="px-5 py-4">
          <div className="flex flex-col gap-1.5">
            <span className={`inline-flex items-center justify-center px-2 py-1 rounded-full text-xs font-bold leading-none ${getStatusBadgeStyle(journal.process)}`}>
              {journal.process}
            </span>
            <span className={`inline-flex items-center justify-center px-2 py-0.5 rounded-full text-[10px] font-semibold leading-none ${getPaymentBadgeStyle(journal.payment)}`}>
              {journal.payment}
            </span>
          </div>
        </td>

        {/* Quick Stepper Status Inline Indicator Column */}
        <td className="px-5 py-4 max-w-[150px]">
          <div className="flex items-center justify-between gap-1 w-full scale-95 origin-right">
            {STAGES.map((s, idx) => {
              const currentIdx = STAGES.findIndex((stage) => stage.value === journal.process);
              const isActive = s.value === journal.process;
              const isPassed = idx < currentIdx;

              return (
                <button
                  key={s.value}
                  type="button"
                  onClick={() => onQuickStatusChange(s.value)}
                  className={`w-4 h-4 rounded-full flex items-center justify-center transition-all ${
                    isActive 
                      ? "bg-indigo-600 text-white ring-2 ring-indigo-200 ring-offset-1 scale-125 font-black" 
                      : isPassed 
                        ? "bg-indigo-100 text-indigo-600 hover:bg-indigo-200" 
                        : "bg-slate-200 text-slate-400 hover:bg-slate-300"
                  }`}
                  title={`Ubah status ke: ${s.label}`}
                >
                  <span className="text-[8px] font-bold">
                    {idx + 1}
                  </span>
                </button>
              );
            })}
          </div>
          <p className="text-[9px] text-right text-slate-400 mt-1.5 italic font-medium">Stepper cepat</p>
        </td>

        {/* Actions Button Column */}
        <td className="px-5 py-4 text-right">
          <div className="flex items-center justify-end gap-1.5">
            <button
              type="button"
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 transition-colors"
              title="Aksi Detail & Hubungi Penulis"
            >
              {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
            <button
              type="button"
              onClick={onEdit}
              className="p-1.5 rounded-lg text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 transition-colors"
              title="Edit Data Jurnal"
            >
              <Edit2 className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={onDelete}
              className="p-1.5 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors"
              title="Hapus Data Jurnal"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </td>
      </tr>

      {/* Expanded Actions & Communication Hub Row */}
      {isExpanded && (
        <tr>
          <td colSpan={7} className="px-6 py-4 bg-gray-50/75 border-b border-gray-100">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-xs text-gray-700">
              
              {/* Column 1: Document/Link Management */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-col gap-3">
                <h4 className="font-bold text-slate-800 flex items-center gap-1.5 border-b border-slate-100 pb-1.5">
                  <FileText className="w-4 h-4 text-indigo-600" /> Pengelolaan URL Berkas
                </h4>

                {/* LoA URL */}
                <div className="flex items-center justify-between gap-2 py-0.5">
                  <span className="font-medium text-gray-600 flex items-center gap-1">
                    <Award className="w-3.5 h-3.5 text-yellow-500" /> URL LoA:
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => onGenerateDoc("loa")}
                      className="px-2 py-1 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white text-[10px] rounded-lg font-bold shadow-xs transition-colors flex items-center gap-1 cursor-pointer"
                      title="Generate & Print LoA (Letter of Acceptance)"
                    >
                      <Printer className="w-3 h-3" /> Cetak LoA
                    </button>
                    {journal.loaUrl ? (
                      <a 
                        href={journal.loaUrl} 
                        target="_blank" 
                        rel="noreferrer" 
                        className="text-yellow-600 hover:text-yellow-850 flex items-center gap-0.5 font-semibold"
                      >
                        Buka <ExternalLink className="w-3 h-3" />
                      </a>
                    ) : (
                      <span className="text-gray-400 italic">Belum ada</span>
                    )}
                    <button
                      type="button"
                      onClick={() => onOpenUrlModal("loaUrl")}
                      className="px-2 py-1 bg-yellow-50 hover:bg-yellow-100 text-yellow-700 text-[10px] rounded font-bold transition-colors"
                    >
                      {journal.loaUrl ? "Edit" : "Tambah"}
                    </button>
                  </div>
                </div>

                {/* Invoice URL */}
                <div className="flex items-center justify-between gap-2 py-0.5">
                  <span className="font-medium text-gray-600 flex items-center gap-1">
                    <DollarSign className="w-3.5 h-3.5 text-green-500" /> URL Invoice:
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => onGenerateDoc("invoice")}
                      className="px-2 py-1 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white text-[10px] rounded-lg font-bold shadow-xs transition-colors flex items-center gap-1 cursor-pointer"
                      title="Generate & Print Invoice APC"
                    >
                      <Printer className="w-3 h-3" /> Cetak Inv
                    </button>
                    {journal.invoiceUrl ? (
                      <a 
                        href={journal.invoiceUrl} 
                        target="_blank" 
                        rel="noreferrer" 
                        className="text-green-600 hover:text-green-800 flex items-center gap-0.5 font-semibold"
                      >
                        Buka <ExternalLink className="w-3 h-3" />
                      </a>
                    ) : (
                      <span className="text-gray-400 italic">Belum ada</span>
                    )}
                    <button
                      type="button"
                      onClick={() => onOpenUrlModal("invoiceUrl")}
                      className="px-2 py-1 bg-green-50 hover:bg-green-100 text-green-700 text-[10px] rounded font-bold transition-colors"
                    >
                      {journal.invoiceUrl ? "Edit" : "Tambah"}
                    </button>
                  </div>
                </div>

                {/* Published URL */}
                <div className="flex items-center justify-between gap-2 py-0.5">
                  <span className="font-medium text-gray-600 flex items-center gap-1">
                    <Link className="w-3.5 h-3.5 text-blue-500" /> Artikel Terbit:
                  </span>
                  <div className="flex items-center gap-1.5">
                    {journal.publishedUrl ? (
                      <a 
                        href={journal.publishedUrl} 
                        target="_blank" 
                        rel="noreferrer" 
                        className="text-blue-600 hover:text-blue-800 flex items-center gap-0.5 font-semibold"
                      >
                        Buka <ExternalLink className="w-3 h-3" />
                      </a>
                    ) : (
                      <span className="text-gray-400 italic">Belum ada</span>
                    )}
                    <button
                      type="button"
                      onClick={() => onOpenUrlModal("publishedUrl")}
                      className="px-2 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 text-[10px] rounded font-bold transition-colors"
                    >
                      {journal.publishedUrl ? "Edit" : "Tambah"}
                    </button>
                  </div>
                </div>

              </div>

              {/* Column 2: Hubungi WhatsApp */}
              <div className="bg-white p-4 rounded-lg border border-gray-150 shadow-xs flex flex-col gap-2.5">
                <h4 className="font-bold text-gray-800 flex items-center gap-1.5 border-b pb-1.5">
                  <Phone className="w-4 h-4 text-emerald-600" /> Hubungi Penulis (WhatsApp)
                </h4>
                <p className="text-[11px] text-gray-400 mb-1">
                  Kirim pesan template instan langsung untuk koordinasi:
                </p>
                
                {/* 1. WhatsApp Revisi */}
                <button
                  type="button"
                  onClick={onSendRevisionWhatsApp}
                  className="w-full flex items-center justify-between px-3 py-2 border border-gray-200 rounded-lg hover:border-emerald-300 hover:bg-emerald-50/20 text-emerald-850 font-bold transition-colors"
                >
                  <span className="flex items-center gap-2">
                    <MessageSquareShare className="w-3.5 h-3.5 text-emerald-600" />
                    Kirim Keputusan Revisi
                  </span>
                  <ExternalLink className="w-3 h-3" />
                </button>

                {/* 2. WhatsApp LoA / Invoice */}
                <button
                  type="button"
                  disabled={!journal.loaUrl && !journal.invoiceUrl}
                  onClick={onSendLoaInvoiceWhatsApp}
                  className={`w-full flex items-center justify-between px-3 py-2 border rounded-lg font-bold transition-all ${
                    journal.loaUrl || journal.invoiceUrl
                      ? "border-gray-200 text-emerald-855 hover:border-emerald-300 hover:bg-emerald-50/20 active:scale-99 cursor-pointer"
                      : "border-gray-100 text-gray-300 cursor-not-allowed bg-gray-50"
                  }`}
                  title={!(journal.loaUrl || journal.invoiceUrl) ? "Tambahkan URL LoA atau Link Invoice dulu di sebelah kiri!" : ""}
                >
                  <span className="flex items-center gap-2">
                    <MessageSquareShare className="w-3.5 h-3.5 text-emerald-600" />
                    Kirim LoA & Invoice (Penagihan)
                  </span>
                  <ExternalLink className="w-3 h-3" />
                </button>

                {/* 3. WhatsApp Terbit */}
                <button
                  type="button"
                  disabled={!journal.publishedUrl}
                  onClick={onSendPublishWhatsApp}
                  className={`w-full flex items-center justify-between px-3 py-2 border rounded-lg font-bold transition-all ${
                    journal.publishedUrl
                      ? "border-gray-200 text-emerald-855 hover:border-emerald-300 hover:bg-emerald-50/20 active:scale-99 cursor-pointer"
                      : "border-gray-100 text-gray-300 cursor-not-allowed bg-gray-50"
                  }`}
                  title={!journal.publishedUrl ? "Masukkan URL Terbit dulu di sebelah kiri!" : ""}
                >
                  <span className="flex items-center gap-2">
                    <MessageSquareShare className="w-3.5 h-3.5 text-emerald-600" />
                    Kirim Link Artikel Terbit
                  </span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>

              {/* Column 3: Hubungi Email */}
              <div className="bg-white p-4 rounded-lg border border-gray-150 shadow-xs flex flex-col gap-2.5">
                <h4 className="font-bold text-gray-800 flex items-center gap-1.5 border-b pb-1.5">
                  <Mail className="w-4 h-4 text-purple-600" /> Hubungi Penulis (Email Koresponden)
                </h4>
                <p className="text-[11px] text-gray-400 mb-1">
                  Kirim draf email redaksional formal secara instan:
                </p>

                {/* 1. Email Revisi */}
                <button
                  type="button"
                  onClick={onSendRevisionEmail}
                  className="w-full flex items-center justify-between px-3 py-2 border border-gray-200 rounded-lg hover:border-purple-300 hover:bg-purple-50/20 text-purple-900 font-bold transition-colors"
                >
                  <span className="flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-purple-600" />
                    Kirim Email Revisi
                  </span>
                  <ExternalLink className="w-3 h-3" />
                </button>

                {/* 2. Email LoA / Invoice */}
                <button
                  type="button"
                  disabled={!journal.loaUrl && !journal.invoiceUrl}
                  onClick={onSendLoaInvoiceEmail}
                  className={`w-full flex items-center justify-between px-3 py-2 border rounded-lg font-bold transition-all ${
                    journal.loaUrl || journal.invoiceUrl
                      ? "border-gray-200 text-purple-900 hover:border-purple-300 hover:bg-purple-50/20 active:scale-99 cursor-pointer"
                      : "border-gray-100 text-gray-300 cursor-not-allowed bg-gray-50"
                  }`}
                  title={!(journal.loaUrl || journal.invoiceUrl) ? "Tambahkan URL LoA atau Link Invoice dulu di sebelah kiri!" : ""}
                >
                  <span className="flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-purple-600" />
                    Kirim Email LoA / Invoice
                  </span>
                  <ExternalLink className="w-3 h-3" />
                </button>

                {/* 3. Email Terbit */}
                <button
                  type="button"
                  disabled={!journal.publishedUrl}
                  onClick={onSendPublishEmail}
                  className={`w-full flex items-center justify-between px-3 py-2 border rounded-lg font-bold transition-all ${
                    journal.publishedUrl
                      ? "border-gray-200 text-purple-900 hover:border-purple-300 hover:bg-purple-50/20 active:scale-99 cursor-pointer"
                      : "border-gray-100 text-gray-300 cursor-not-allowed bg-gray-50"
                  }`}
                  title={!journal.publishedUrl ? "Masukkan URL Terbit dulu di sebelah kiri!" : ""}
                >
                  <span className="flex items-center gap-2">
                    <Mail className="w-3.5 h-3.5 text-purple-600" />
                    Kirim Email Artikel Terbit
                  </span>
                  <ExternalLink className="w-3 h-3" />
                </button>
              </div>

            </div>
          </td>
        </tr>
      )}
    </React.Fragment>
  );
}
