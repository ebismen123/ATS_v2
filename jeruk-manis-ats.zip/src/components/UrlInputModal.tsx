/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { X, Save, Award, Receipt, Link, AlertCircle } from "lucide-react";

interface UrlInputModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (url: string) => void;
  type: "publishedUrl" | "loaUrl" | "invoiceUrl" | null;
  initialUrl?: string;
}

export function UrlInputModal({ isOpen, onClose, onSave, type, initialUrl }: UrlInputModalProps) {
  const [url, setUrl] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    setUrl(initialUrl || "");
    setError("");
  }, [initialUrl, isOpen]);

  if (!isOpen || !type) return null;

  let title = "";
  let description = "";
  let icon = <Link className="w-10 h-10 text-orange-500" />;
  let placeholder = "https://...";
  let bgIconClass = "bg-orange-50";

  if (type === "publishedUrl") {
    title = "Masukkan URL Artikel Terbit";
    description = "Masukkan URL lengkap artikel jurnal yang sudah resmi dipublikasikan secara daring.";
    icon = <Link className="w-6 h-6 text-blue-600" />;
    bgIconClass = "bg-blue-50";
    placeholder = "https://example-journal.com/articles/amni-345";
  } else if (type === "loaUrl") {
    title = "Masukkan URL Letter of Acceptance (LoA)";
    description = "Masukkan link berkas LoA resmi dari Google Drive, Dropbox, atau server utama Anda.";
    icon = <Award className="w-6 h-6 text-yellow-600" />;
    bgIconClass = "bg-yellow-50";
    placeholder = "https://drive.google.com/file/d/xxxxxx/view";
  } else if (type === "invoiceUrl") {
    title = "Masukkan URL Berkas Invoice";
    description = "Sediakan URL invoice/penagihan administrasi penulis agar dapat dikirimkan instan.";
    icon = <Receipt className="w-6 h-6 text-green-600" />;
    bgIconClass = "bg-green-50";
    placeholder = "https://drive.google.com/file/d/invoice-xxxxxx/view";
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedUrl = url.trim();
    if (!trimmedUrl) {
      setError("URL tidak boleh kosong.");
      return;
    }

    try {
      new URL(trimmedUrl);
      onSave(trimmedUrl);
    } catch (_) {
      setError("Format URL tidak valid. Harap gunakan format lengkap (http:// atau https://).");
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs" onClick={onClose} />

      <div className="relative bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden flex flex-col border border-gray-150 animate-scale-up">
        <div className="px-5 py-4 border-b border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${bgIconClass}`}>
              {icon}
            </div>
            <h3 className="text-sm font-bold text-gray-800">{title}</h3>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          <p className="text-xs text-gray-500 leading-normal">
            {description}
          </p>

          <div>
            <label className="block text-[11px] font-bold text-gray-500 uppercase tracking-wider mb-1">
              Alamat URL Berkas
            </label>
            <input
              type="text"
              required
              value={url}
              onChange={(e) => {
                setUrl(e.target.value);
                setError("");
              }}
              placeholder={placeholder}
              className="w-full text-xs rounded-lg border border-gray-300 px-3 py-2.5 focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
            />
            {error && (
              <p className="text-[10px] text-red-650 font-medium mt-1.5 flex items-center gap-1 leading-normal">
                <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                {error}
              </p>
            )}
          </div>

          <div className="pt-2 flex justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 border border-gray-300 rounded-lg hover:bg-gray-50 text-xs font-semibold text-gray-700 transition-colors"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 bg-gradient-to-r from-orange-500 to-amber-500 text-white text-xs font-bold rounded-lg hover:opacity-90 flex items-center gap-1 transition-all"
            >
              <Save className="w-3.5 h-3.5" />
              Simpan URL
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
