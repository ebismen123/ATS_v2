/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { Journal, ProcessStatus, PaymentStatus, BillingTiming, PublicationType } from "../types";
import { X, Save, AlertCircle } from "lucide-react";

interface JournalFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Journal) => void;
  initialData?: Journal | null;
  title: string;
}

const JOURNAL_OPTIONS = [
  "EBISMEN",
  "WAWASAN",
  "PROFIT",
  "POPULER",
  "SIDU",
  "INSDU",
  "OCEAN",
  "KTI",
  "SEJAHTERA",
  "KARUNIA",
  "UNITECH",
];

const MONTH_OPTIONS = [
  "Januari", "Februari", "Maret", "April", "Mei", "Juni",
  "Juli", "Agustus", "September", "Oktober", "November", "Desember"
];

const PROCESS_OPTIONS: { value: ProcessStatus; label: string }[] = [
  { value: "Belum submit", label: "Belum submit" },
  { value: "Sudah disubmit", label: "Sudah disubmit" },
  { value: "Review", label: "Review" },
  { value: "Editing", label: "Editing" },
  { value: "LoA sudah terbit", label: "LoA sudah terbit" },
  { value: "Publish", label: "Publish" },
];

export function JournalFormModal({ isOpen, onClose, onSave, initialData, title }: JournalFormModalProps) {
  const [entryDate, setEntryDate] = useState("");
  const [authorName, setAuthorName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [affiliation, setAffiliation] = useState("");
  const [journalTitle, setJournalTitle] = useState("");
  const [articleNumber, setArticleNumber] = useState("");
  const [volume, setVolume] = useState("");
  const [issueNumber, setIssueNumber] = useState("");
  const [publishMonth, setPublishMonth] = useState("Januari");
  const [publishYear, setPublishYear] = useState(new Date().getFullYear().toString());
  const [publicationType, setPublicationType] = useState<PublicationType>("Reguler");
  const [apcAmount, setApcAmount] = useState("100000");
  const [journalTarget, setJournalTarget] = useState("");
  const [deadline, setDeadline] = useState("");
  const [process, setProcess] = useState<ProcessStatus>("Belum submit");
  const [payment, setPayment] = useState<PaymentStatus>("Belum Bayar");
  const [billingTiming, setBillingTiming] = useState<BillingTiming>("Sekarang");

  // Format phone number to replace starting '0' with '62' (international) and non-digits
  const cleanAndFormatPhone = (val: string) => {
    let cleaned = val.replace(/\D/g, '');
    if (cleaned.startsWith('0')) {
      cleaned = '62' + cleaned.substring(1);
    }
    return cleaned;
  };

  // Populate data when editing
  useEffect(() => {
    if (initialData) {
      setEntryDate(initialData.entryDate || "");
      setAuthorName(initialData.authorName || "");
      setEmail(initialData.email || "");
      setPhone(initialData.phone || "");
      setAffiliation(initialData.affiliation || "");
      setJournalTitle(initialData.title || "");
      setArticleNumber(initialData.articleNumber || "");
      setVolume(initialData.volume?.toString() || "");
      setIssueNumber(initialData.issueNumber?.toString() || "");
      setPublishMonth(initialData.publishMonth || "Januari");
      setPublishYear(initialData.publishYear?.toString() || new Date().getFullYear().toString());
      setPublicationType(initialData.publicationType || "Reguler");
      setApcAmount(initialData.apcAmount?.toString() || "100000");
      setJournalTarget(initialData.journalTarget || "");
      setDeadline(initialData.deadline || "");
      setProcess(initialData.process || "Belum submit");
      setPayment(initialData.payment || "Belum Bayar");
      setBillingTiming(initialData.billingTiming || "Sekarang");
    } else {
      // Default initial states for adding new
      const today = new Date().toISOString().split('T')[0];
      setEntryDate(today);
      setAuthorName("");
      setEmail("");
      setPhone("");
      setAffiliation("");
      setJournalTitle("");
      setArticleNumber("");
      setVolume("");
      setIssueNumber("");
      
      const currentMonth = MONTH_OPTIONS[new Date().getMonth()];
      setPublishMonth(currentMonth);
      setPublishYear(new Date().getFullYear().toString());
      setPublicationType("Reguler");
      setApcAmount("100000");
      setJournalTarget("");
      setProcess("Belum submit");
      setPayment("Belum Bayar");
      setBillingTiming("Sekarang");
    }
  }, [initialData, isOpen]);

  // Recalculate deadline and apc amount automatic helpers
  useEffect(() => {
    if (!entryDate) return;
    
    // Calcula deadline: +2 days for Fast Track, +8 days for Reguler
    const dateObj = new Date(entryDate);
    const daysToAdd = publicationType === "Fast Track" ? 2 : 8;
    dateObj.setDate(dateObj.getDate() + daysToAdd);
    setDeadline(dateObj.toISOString().split("T")[0]);

    // Recalculate default fee if not customized yet when switching type: FAST TRACK = 200000, REGULAR = 100000
    if (!initialData) {
      setApcAmount(publicationType === "Fast Track" ? "200000" : "100000");
    }
  }, [entryDate, publicationType, initialData]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!journalTarget) {
      alert("Silakan pilih Jurnal yang dituju!");
      return;
    }

    const compiledData: Journal = {
      entryDate,
      authorName: authorName.trim(),
      email: email.trim(),
      phone: cleanAndFormatPhone(phone),
      affiliation: affiliation.trim(),
      title: journalTitle.trim(),
      articleNumber: articleNumber.trim(),
      volume: volume ? Number(volume) : "",
      issueNumber: issueNumber ? Number(issueNumber) : "",
      publishMonth,
      publishYear: Number(publishYear) || new Date().getFullYear(),
      publicationType,
      apcAmount: Number(apcAmount) || 0,
      journalTarget,
      deadline,
      process,
      payment,
      billingTiming,
    };

    onSave(compiledData);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity" 
        onClick={onClose}
      />

      {/* Modal Dialog */}
      <div className="relative bg-white rounded-2xl shadow-xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh] border border-gray-100 animate-scale-up">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between bg-gradient-to-r from-orange-500 to-amber-500 text-white">
          <div>
            <h3 className="text-lg font-bold">{title}</h3>
            <p className="text-[11px] text-orange-100 mt-0.5">Lengkapi parameters dengan data valid artikel jurnal.</p>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded-full text-white/80 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body (Scrollable) */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-5">
          
          {/* Section 1: Data Penulis */}
          <div>
            <h4 className="text-xs font-bold text-orange-600 uppercase tracking-widest border-b border-orange-100 pb-1.5 mb-3 flex items-center gap-1">
              <span>👤</span> Penulis & Korespondensi
            </h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase">Nama Penulis Utama</label>
                <input 
                  type="text" 
                  required 
                  value={authorName} 
                  onChange={(e) => setAuthorName(e.target.value)} 
                  placeholder="Masukkan nama lengkap penulis"
                  className="mt-1 block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase">Afiliasi / Instansi</label>
                <input 
                  type="text" 
                  required 
                  value={affiliation} 
                  onChange={(e) => setAffiliation(e.target.value)} 
                  placeholder="Contoh: Universitas Gadjah Mada"
                  className="mt-1 block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase">Email Koresponden</label>
                <input 
                  type="email" 
                  required 
                  value={email} 
                  onChange={(e) => setEmail(e.target.value)} 
                  placeholder="author@example.com"
                  className="mt-1 block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase">Nomor HP / WhatsApp (Penulis)</label>
                <input 
                  type="text" 
                  required 
                  value={phone} 
                  onChange={(e) => setPhone(e.target.value)} 
                  placeholder="628xxxxxxxx atau 08xxxxxxxx"
                  className="mt-1 block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
                />
                <p className="text-[10px] text-gray-400 mt-1">Prefiks 0 asli diubah global ke format internasional 62 secara otomatis.</p>
              </div>
            </div>
          </div>

          {/* Section 2: Metadata Naskah */}
          <div>
            <h4 className="text-xs font-bold text-orange-600 uppercase tracking-widest border-b border-orange-100 pb-1.5 mb-3 flex items-center gap-1">
              <span>📄</span> Informasi Artikel (Naskah)
            </h4>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase">Judul Artikel Lengkap</label>
                <textarea 
                  required 
                  rows={2}
                  value={journalTitle} 
                  onChange={(e) => setJournalTitle(e.target.value)} 
                  placeholder="Tuliskan judul lengkap naskah yang dikirim..."
                  className="mt-1 block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">Nomor Artikel (ID)</label>
                  <input 
                    type="text" 
                    required 
                    value={articleNumber} 
                    onChange={(e) => setArticleNumber(e.target.value)} 
                    placeholder="Contoh: AMNI-345"
                    className="mt-1 block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">Volume Jurnal</label>
                  <input 
                    type="number" 
                    value={volume} 
                    onChange={(e) => setVolume(e.target.value)} 
                    placeholder="Contoh: 12"
                    className="mt-1 block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase">Terbitan (No/Issue)</label>
                  <input 
                    type="number" 
                    value={issueNumber} 
                    onChange={(e) => setIssueNumber(e.target.value)} 
                    placeholder="Contoh: 2"
                    className="mt-1 block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Penerbitan & Finansial */}
          <div>
            <h4 className="text-xs font-bold text-orange-600 uppercase tracking-widest border-b border-orange-100 pb-1.5 mb-3 flex items-center gap-1">
              <span>📚</span> Penerbitan, Pengiriman & APC
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase">Jurnal Penerbit Jurnal Aliansi</label>
                <select 
                  required 
                  value={journalTarget} 
                  onChange={(e) => setJournalTarget(e.target.value)}
                  className="mt-1 block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500 bg-white"
                >
                  <option value="">-- Pilih Jurnal yang Dituju --</option>
                  {JOURNAL_OPTIONS.map((j) => (
                    <option key={j} value={j}>{j}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase">Jenis Publikasi</label>
                <select 
                  value={publicationType} 
                  onChange={(e) => setPublicationType(e.target.value as PublicationType)}
                  className="mt-1 block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500 bg-white"
                >
                  <option value="Reguler">Reguler (8 Hari) - Rp 100k</option>
                  <option value="Fast Track">Fast Track (2 Hari) - Rp 200k</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase">Biaya Publikasi (APC) - Rupiah</label>
                <input 
                  type="number" 
                  required 
                  value={apcAmount} 
                  onChange={(e) => setApcAmount(e.target.value)} 
                  placeholder="Contoh: 100000"
                  className="mt-1 block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-gray-500">Bulan Terbit</label>
                  <select 
                    value={publishMonth} 
                    onChange={(e) => setPublishMonth(e.target.value)}
                    className="mt-1 block w-full rounded-lg border border-gray-300 px-2 py-2 text-xs focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500 bg-white"
                  >
                    {MONTH_OPTIONS.map((m) => (
                      <option key={m} value={m}>{m}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-500">Tahun Terbit</label>
                  <input 
                    type="number" 
                    required 
                    value={publishYear} 
                    onChange={(e) => setPublishYear(e.target.value)}
                    className="mt-1 block w-full rounded-lg border border-gray-300 px-2 py-2 text-xs focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase">Tanggal Masuk</label>
                <input 
                  type="date" 
                  required 
                  value={entryDate} 
                  onChange={(e) => setEntryDate(e.target.value)} 
                  className="mt-1 block w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase flex items-center gap-1">
                  Tanggal Deadline <AlertCircle className="w-3.5 h-3.5 text-orange-500" title="Dihitung otomatis berdasarkan Tanggal Masuk + jenis Fast Track/Reguler" />
                </label>
                <input 
                  type="date" 
                  required 
                  value={deadline} 
                  onChange={(e) => setDeadline(e.target.value)}
                  className="mt-1 block w-full bg-orange-50/50 rounded-lg border border-orange-200 px-3 py-2 text-sm font-semibold text-orange-800 focus:border-orange-500 focus:outline-none focus:ring-1 focus:ring-orange-500"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Status Alur Kerja / Status Administrasi */}
          <div>
            <h4 className="text-xs font-bold text-orange-600 uppercase tracking-widest border-b border-orange-100 pb-1.5 mb-3 flex items-center gap-1">
              <span>⚙️</span> Pelacakan Alur Kerja & Pembayaran
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Process Status selection */}
              <div className="bg-slate-50/50 p-4 rounded-xl border border-slate-100">
                <span className="block text-xs font-bold text-gray-600 uppercase tracking-wider mb-2.5">Proses Tahapan</span>
                <div className="space-y-2.5">
                  {PROCESS_OPTIONS.map((o) => (
                    <label key={o.value} className="flex items-center gap-2 text-xs font-medium text-gray-700 cursor-pointer hover:text-orange-600">
                      <input 
                        type="radio" 
                        name="process" 
                        value={o.value} 
                        checked={process === o.value} 
                        onChange={() => setProcess(o.value)}
                        className="text-orange-500 focus:ring-orange-500 h-4 w-4"
                      />
                      {o.label}
                    </label>
                  ))}
                </div>
              </div>

              {/* Payment Status selection */}
              <div className="bg-slate-50/50 p-4 rounded-xl border border-slate-100 flex flex-col justify-between">
                <div>
                  <span className="block text-xs font-bold text-gray-600 uppercase tracking-wider mb-2.5">Status Pembayaran</span>
                  <div className="space-y-2.5 mb-4">
                    <label className="flex items-center gap-2 text-xs font-medium text-gray-700 cursor-pointer">
                      <input 
                        type="radio" 
                        name="payment" 
                        value="Sudah Bayar" 
                        checked={payment === "Sudah Bayar"} 
                        onChange={() => setPayment("Sudah Bayar")}
                        className="text-orange-500 focus:ring-orange-500 h-4 w-4"
                      />
                      Sudah Bayar
                    </label>
                    <label className="flex items-center gap-2 text-xs font-medium text-gray-700 cursor-pointer">
                      <input 
                        type="radio" 
                        name="payment" 
                        value="Belum Bayar" 
                        checked={payment === "Belum Bayar"} 
                        onChange={() => setPayment("Belum Bayar")}
                        className="text-orange-500 focus:ring-orange-500 h-4 w-4"
                      />
                      Belum Bayar
                    </label>
                  </div>
                </div>

                <div className="bg-orange-50/30 p-2.5 rounded-lg border border-orange-100">
                  <p className="text-[10px] text-orange-850 leading-tight italic">
                    Status pembayaran dapat diperbarui instan nanti melalui panel edit atau log pembayaran.
                  </p>
                </div>
              </div>

              {/* Billing timing selection */}
              <div className="bg-slate-50/50 p-4 rounded-xl border border-slate-100 flex flex-col justify-between">
                <div>
                  <span className="block text-xs font-bold text-gray-600 uppercase tracking-wider mb-2.5">Waktu Penagihan</span>
                  <div className="space-y-2.5 mb-4">
                    <label className="flex items-center gap-2 text-xs font-medium text-gray-700 cursor-pointer">
                      <input 
                        type="radio" 
                        name="billingTiming" 
                        value="Sekarang" 
                        checked={billingTiming === "Sekarang"} 
                        onChange={() => setBillingTiming("Sekarang")}
                        className="text-orange-500 focus:ring-orange-500 h-4 w-4"
                      />
                      Sekarang (Saat LoA)
                    </label>
                    <label className="flex items-center gap-2 text-xs font-medium text-gray-700 cursor-pointer">
                      <input 
                        type="radio" 
                        name="billingTiming" 
                        value="Nanti" 
                        checked={billingTiming === "Nanti"} 
                        onChange={() => setBillingTiming("Nanti")}
                        className="text-orange-500 focus:ring-orange-500 h-4 w-4"
                      />
                      Nanti (Saat Publish)
                    </label>
                  </div>
                </div>

                <div className="bg-slate-100 p-2.5 rounded-lg">
                  <p className="text-[10px] text-gray-500 leading-tight">
                    Mengontrol kapan template invoice aktif dikirimkan ke koresponden.
                  </p>
                </div>
              </div>
            </div>
          </div>

        </form>

        {/* Form Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-gray-150 flex items-center justify-end gap-3">
          <button 
            type="button" 
            onClick={onClose} 
            className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-100 font-bold text-sm transition-colors"
          >
            Batal
          </button>
          <button 
            type="button" 
            onClick={handleSubmit} 
            className="px-5 py-2 bg-gradient-to-r from-orange-500 to-amber-500 text-white font-bold text-sm rounded-lg hover:opacity-90 flex items-center gap-1.5 shadow-md active:scale-98 transition-all"
          >
            <Save className="w-4 h-4" /> Simpan Data Jurnal
          </button>
        </div>
      </div>
    </div>
  );
}
