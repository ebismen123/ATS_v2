/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Journal } from "../types";
import { 
  BookOpen, 
  Zap, 
  AlertTriangle, 
  DollarSign, 
  CheckCircle2, 
  Clock 
} from "lucide-react";

interface StatCardsProps {
  journals: Journal[];
  onSelectActionNeededFilter: () => void;
  isActionNeededFiltered: boolean;
}

export function StatCards({ journals, onSelectActionNeededFilter, isActionNeededFiltered }: StatCardsProps) {
  const total = journals.length;
  const fastTrack = journals.filter(j => j.publicationType === "Fast Track").length;
  const regular = total - fastTrack;
  const published = journals.filter(j => j.process === "Publish").length;
  const inProgress = total - published;

  // APC Calculations
  let revenueCollected = 0;
  let revenuePending = 0;

  // Let's analyze "Needs Action / Tindak Lanjut" count
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const actionNeededJournals = journals.filter(j => {
    if (j.process === "Publish") return false;

    // 1. Overdue or soon-to-be overdue (<= 2 days)
    const deadlineDate = new Date(j.deadline);
    const timeDiff = deadlineDate.getTime() - today.getTime();
    const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
    const isUrgentDeadline = daysDiff <= 2;

    // 2. Unpaid and billing is urgent ("Sekarang")
    const unpaidUrgentBilling = j.payment === "Belum Bayar" && j.billingTiming === "Sekarang";

    // 3. Review process or Edit process taking too long (e.g., let's consider stuck logic if applicable, but simple criteria is fine)
    return isUrgentDeadline || unpaidUrgentBilling;
  });

  journals.forEach(j => {
    const amount = Number(j.apcAmount) || 0;
    if (j.payment === "Sudah Bayar") {
      revenueCollected += amount;
    } else {
      revenuePending += amount;
    }
  });

  const actionCount = actionNeededJournals.length;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {/* Total Card */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 flex items-center justify-between shadow-xs hover:shadow-sm transition-shadow duration-300">
        <div>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Manajemen Jurnal</p>
          <h3 className="text-3xl font-black text-slate-900 tracking-tight mt-1">{total}</h3>
          <div className="flex gap-2.5 items-center mt-2 text-xs font-medium text-slate-500">
            <span className="flex items-center gap-1 text-emerald-600">
              <CheckCircle2 className="w-3.5 h-3.5" /> {published} Terbit
            </span>
            <span className="text-slate-300">•</span>
            <span className="flex items-center gap-1 text-indigo-500">
              <Clock className="w-3.5 h-3.5" /> {inProgress} Berjalan
            </span>
          </div>
        </div>
        <div className="w-12 h-12 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-600 border border-indigo-100/50">
          <BookOpen className="w-5.5 h-5.5" />
        </div>
      </div>

      {/* Fast Track Card */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 flex items-center justify-between shadow-xs hover:shadow-sm transition-shadow duration-300">
        <div>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Metode Pengiriman</p>
          <h3 className="text-3xl font-black text-slate-900 tracking-tight mt-1">
            {fastTrack} <span className="text-sm font-normal text-slate-500">Fast Track</span>
          </h3>
          <p className="text-xs text-slate-500 mt-2 font-medium">
            Reguler: <span className="font-bold text-slate-800">{regular} naskah</span>
          </p>
        </div>
        <div className="w-12 h-12 rounded-2xl bg-purple-50 flex items-center justify-center text-purple-600 border border-purple-100/50">
          <Zap className="w-5.5 h-5.5" />
        </div>
      </div>

      {/* Tindak Lanjut / Follow Up Urgent Card (Clickable!) */}
      <button 
        type="button"
        onClick={onSelectActionNeededFilter}
        className={`text-left rounded-3xl p-6 flex items-center justify-between transition-all duration-300 border ${
          isActionNeededFiltered 
            ? "bg-rose-100/75 border-rose-300 ring-4 ring-rose-150 shadow-md"
            : "bg-rose-50/50 border-rose-100 hover:border-rose-200 hover:bg-rose-50 hover:shadow-sm"
        } cursor-pointer group`}
      >
        <div>
          <p className="text-xs font-bold text-rose-500 uppercase tracking-wider group-hover:text-rose-700 transition-colors">Butuh Tindak Lanjut</p>
          <div className="flex items-baseline gap-2 mt-1">
            <h3 className={`text-3xl font-black tracking-tight ${actionCount > 0 ? "text-rose-700" : "text-slate-805"}`}>
              {actionCount}
            </h3>
            {actionCount > 0 && (
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-600"></span>
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-2 group-hover:text-rose-600 font-medium transition-colors">
            {isActionNeededFiltered ? "✓ Menyaring yang urgent" : "Klik untuk saring data urgent 🚨"}
          </p>
        </div>
        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${
          actionCount > 0 
            ? "bg-rose-200/60 text-rose-700 border border-rose-305 group-hover:bg-rose-200" 
            : "bg-slate-100 text-slate-400 border border-slate-200"
        }`}>
          <AlertTriangle className="w-5.5 h-5.5" />
        </div>
      </button>

      {/* Keuangan Jurnal Card */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 flex items-center justify-between shadow-xs hover:shadow-sm transition-shadow duration-300">
        <div>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Status Administrasi APC</p>
          <h3 className="text-xl font-bold text-emerald-600 mt-1 tracking-tight">
            Rp {revenueCollected.toLocaleString("id-ID")}
            <span className="text-[10px] uppercase font-bold text-slate-400 block mt-0.5 tracking-wider">Telah Dibayar</span>
          </h3>
          <p className="text-[11px] text-rose-605 font-semibold mt-1.5 bg-rose-50 border border-rose-100/50 px-2 py-0.5 rounded-md inline-block">
            Tertunda: Rp {revenuePending.toLocaleString("id-ID")}
          </p>
        </div>
        <div className="w-12 h-12 rounded-2xl bg-emerald-50 flex items-center justify-center text-emerald-600 border border-emerald-100/50">
          <DollarSign className="w-5.5 h-5.5" />
        </div>
      </div>
    </div>
  );
}
