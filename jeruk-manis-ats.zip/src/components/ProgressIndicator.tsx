/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ProcessStatus } from "../types";
import { Check, Circle } from "lucide-react";

interface ProgressIndicatorProps {
  currentStatus: ProcessStatus;
  onStatusChange?: (newStatus: ProcessStatus) => void;
  interactive?: boolean;
}

export const STAGES: { value: ProcessStatus; label: string; color: string; bg: string; text: string }[] = [
  { value: "Belum submit", label: "Belum Submit", color: "bg-gray-400", bg: "bg-gray-50", text: "text-gray-600" },
  { value: "Sudah disubmit", label: "Disubmit", color: "bg-blue-500", bg: "bg-blue-50", text: "text-blue-700" },
  { value: "Review", label: "Review", color: "bg-amber-500", bg: "bg-amber-50", text: "text-amber-800" },
  { value: "Editing", label: "Editing", color: "bg-purple-500", bg: "bg-purple-50", text: "text-purple-700" },
  { value: "LoA sudah terbit", label: "LoA Terbit", color: "bg-cyan-500", bg: "bg-cyan-50", text: "text-cyan-700" },
  { value: "Publish", label: "Publish", color: "bg-green-500", bg: "bg-green-50", text: "text-green-700" },
];

export function ProgressIndicator({ currentStatus, onStatusChange, interactive = false }: ProgressIndicatorProps) {
  const currentIndex = STAGES.findIndex((s) => s.value === currentStatus);

  return (
    <div className="w-full py-2">
      {/* ProgressBar for layout */}
      <div className="relative flex items-center justify-between">
        {/* Background Line */}
        <div className="absolute top-1/2 left-0 right-0 h-1 bg-gray-200 -translate-y-1/2 rounded-full z-0" />
        
        {/* Active Fill Line */}
        <div 
          className="absolute top-1/2 left-0 h-1 bg-orange-500 -translate-y-1/2 rounded-full transition-all duration-500 z-0" 
          style={{ width: `${(currentIndex / (STAGES.length - 1)) * 100}%` }}
        />

        {/* Dots */}
        {STAGES.map((stage, idx) => {
          const isCompleted = idx < currentIndex;
          const isActive = idx === currentIndex;
          const isPending = idx > currentIndex;

          let dotClass = "border-2 bg-white ";
          if (isCompleted) {
            dotClass += "border-orange-500 text-orange-500 hover:scale-110";
          } else if (isActive) {
            dotClass += "border-orange-500 text-white bg-orange-500 ring-4 ring-orange-100 scale-110";
          } else {
            dotClass += "border-gray-300 text-gray-400 hover:border-gray-400";
          }

          return (
            <div 
              key={stage.value} 
              className="relative flex flex-col items-center flex-1 z-10"
            >
              <button
                type="button"
                disabled={!interactive || !onStatusChange}
                onClick={() => onStatusChange && onStatusChange(stage.value)}
                className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center transition-all ${dotClass} ${interactive ? 'cursor-pointer' : 'cursor-default'}`}
                title={`Ubah status ke: ${stage.label}`}
              >
                {isCompleted ? (
                  <Check className="w-4 h-4 text-orange-500 font-bold" />
                ) : isActive ? (
                  <span className="w-2 h-2 rounded-full bg-white animate-ping absolute" />
                ) : (
                  <Circle className="w-3 h-3 text-current fill-current opacity-30" />
                )}
                {isActive && <span className="w-2 h-2 rounded-full bg-white" />}
              </button>

              {/* Label */}
              <span className={`hidden md:block text-[10px] font-medium mt-1.5 text-center px-1 transition-all ${
                isActive ? "text-orange-600 font-semibold scale-105" : isCompleted ? "text-gray-700" : "text-gray-400"
              }`}>
                {stage.label}
              </span>
            </div>
          );
        })}
      </div>

      {/* Tiny descriptive state for Mobile */}
      <div className="md:hidden flex justify-between items-center mt-2 px-2 text-xs">
        <span className="text-gray-500 font-medium">Progress:</span>
        <span className={`px-2 py-0.5 rounded-full font-bold text-[11px] ${STAGES[currentIndex]?.bg} ${STAGES[currentIndex]?.text}`}>
          {STAGES[currentIndex]?.label}
        </span>
      </div>
    </div>
  );
}
